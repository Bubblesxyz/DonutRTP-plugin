package com.vg.pon.macrokey;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ContainerObjectSelectionList;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class MacroEditScreen extends Screen {
    private final Screen parent;
    private final MacroData data;
    private EditBox nameBox;
    private Button keyBtn;
    private StepListWidget stepList;
    private boolean isListening = false;

    public MacroEditScreen(Screen parent, MacroData data) {
        super(Component.literal("Edit Macro"));
        this.parent = parent;
        this.data = data;
    }

    @Override
    protected void init() {
        this.nameBox = new EditBox(this.font, this.width / 2 - 100, 35, 200, 20, Component.literal("Name"));
        this.nameBox.setValue(this.data.name);
        this.nameBox.setHint(Component.literal("Macro Name..."));
        this.nameBox.setResponder(val -> this.data.name = val);
        this.addRenderableWidget(this.nameBox);
        this.keyBtn = Button.builder(Component.literal("Key: " + this.data.getKeyName()), btn -> {
            this.isListening = !this.isListening;
            this.updateKeyBtn();
        }).bounds(this.width / 2 - 100, 60, 200, 20).build();
        this.addRenderableWidget(this.keyBtn);
        this.stepList = new StepListWidget(this.minecraft, this.width, this.height - 135, 100, 25);
        this.addRenderableWidget(this.stepList);
        this.rebuildSteps();
        this.addRenderableWidget(Button.builder(Component.literal("+ Add Step"), btn -> {
            this.data.steps.add(new MacroData.MacroStep("", 0));
            this.rebuildSteps();
            this.stepList.setScrollAmount(10000.0);
        }).bounds(this.width / 2 - 105, this.height - 28, 100, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Done"), btn -> this.onClose())
                .bounds(this.width / 2 + 5, this.height - 28, 100, 20).build());
    }

    private void updateKeyBtn() {
        if (this.isListening) {
            this.keyBtn.setMessage(Component.literal("> Press Key <").withStyle(s -> s.withColor(0xFFFF00)));
        } else {
            this.keyBtn.setMessage(Component.literal("Key: " + this.data.getKeyName()));
        }
    }

    private void rebuildSteps() {
        this.stepList.reset();
        for (int i = 0; i < this.data.steps.size(); i++) {
            this.stepList.addStep(this.data.steps.get(i));
        }
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (this.isListening) {
            int keyCode = event.key();
            this.data.keyCode = keyCode == 256 ? -1 : keyCode;
            this.isListening = false;
            this.updateKeyBtn();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, this.width, this.height, 0x90000000);
        super.render(g, mouseX, mouseY, partialTick);
        g.drawCenteredString(this.font, "Editing: " + this.data.name, this.width / 2, 15, 0xFFFFFFFF);
        int startX = (this.width - 280) / 2;
        g.drawString(this.font, "Command / Message", startX + 2, 88, 0xFFFFFFFF, false);
        g.drawString(this.font, "Delay", startX + 207, 88, 0xFFFFFFFF, false);
    }

    @Override
    public void onClose() {
        MacroConfig.save();
        this.minecraft.setScreen(this.parent);
    }

    class StepListWidget extends ContainerObjectSelectionList<StepEntry> {
        public StepListWidget(Minecraft mc, int width, int height, int y0, int itemHeight) {
            super(mc, width, height, y0, itemHeight);
        }

        public void addStep(MacroData.MacroStep step) {
            this.addEntry(new StepEntry(step));
        }

        public void reset() {
            this.clearEntries();
        }

        @Override
        public int getRowWidth() {
            return 300;
        }
    }

    class StepEntry extends ContainerObjectSelectionList.Entry<StepEntry> {
        private final MacroData.MacroStep step;
        private final EditBox cmdBox;
        private final EditBox delayBox;
        private final Button delBtn;

        public StepEntry(MacroData.MacroStep step) {
            this.step = step;
            this.cmdBox = new EditBox(MacroEditScreen.this.font, 0, 0, 200, 20, Component.literal("Cmd"));
            this.cmdBox.setMaxLength(256);
            this.cmdBox.setValue(step.command);
            this.cmdBox.setHint(Component.literal("Command..."));
            this.cmdBox.setResponder(v -> step.command = v);
            this.delayBox = new EditBox(MacroEditScreen.this.font, 0, 0, 50, 20, Component.literal("Delay"));
            this.delayBox.setValue(String.valueOf(step.delay));
            this.delayBox.setHint(Component.literal("Ticks"));
            this.delayBox.setResponder(v -> {
                try {
                    step.delay = Integer.parseInt(v);
                } catch (Exception ignored) {
                }
            });
            this.delBtn = Button.builder(Component.literal("X"), b -> {
                MacroEditScreen.this.data.steps.remove(step);
                MacroEditScreen.this.rebuildSteps();
            }).bounds(0, 0, 20, 20).build();
        }

        @Override
        public void renderContent(GuiGraphics g, int mx, int my, boolean h, float pt) {
            int top = this.getContentY();
            int left = this.getContentX();
            int width = this.getContentWidth();
            int startX = left + (width - 280) / 2;
            cmdBox.setX(startX);
            cmdBox.setY(top);
            delayBox.setX(startX + 205);
            delayBox.setY(top);
            delBtn.setX(startX + 260);
            delBtn.setY(top);
            cmdBox.render(g, mx, my, pt);
            delayBox.render(g, mx, my, pt);
            delBtn.render(g, mx, my, pt);
        }

        @Override
        public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
            if (cmdBox.mouseClicked(event, doubleClick)) {
                this.setFocused(cmdBox);
                return true;
            }
            if (delayBox.mouseClicked(event, doubleClick)) {
                this.setFocused(delayBox);
                return true;
            }
            return delBtn.mouseClicked(event, doubleClick);
        }

        @Override
        public boolean charTyped(CharacterEvent event) {
            if (this.getFocused() == cmdBox) return cmdBox.charTyped(event);
            if (this.getFocused() == delayBox) return delayBox.charTyped(event);
            return false;
        }

        @Override
        public boolean keyPressed(KeyEvent event) {
            if (this.getFocused() == cmdBox) return cmdBox.keyPressed(event);
            if (this.getFocused() == delayBox) return delayBox.keyPressed(event);
            return false;
        }

        @Override
        public List<? extends GuiEventListener> children() {
            return List.of(cmdBox, delayBox, delBtn);
        }

        @Override
        public List<? extends NarratableEntry> narratables() {
            return List.of(cmdBox, delayBox, delBtn);
        }
    }
}
