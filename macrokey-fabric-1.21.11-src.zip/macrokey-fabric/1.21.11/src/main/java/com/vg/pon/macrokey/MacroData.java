package com.vg.pon.macrokey;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.ArrayList;
import java.util.List;

public class MacroData {
    public String name;
    public int keyCode;
    public boolean active;
    public List<MacroStep> steps = new ArrayList<>();

    public MacroData(String name, int keyCode) {
        this.name = name;
        this.keyCode = keyCode;
        this.active = true;
        this.steps.add(new MacroStep("/say Hello", 0));
    }

    public String getKeyName() {
        if (this.keyCode == -1) {
            return "NONE";
        }
        return InputConstants.Type.KEYSYM.getOrCreate(this.keyCode).getDisplayName().getString();
    }

    public static class MacroStep {
        public String command;
        public int delay;

        public MacroStep(String command, int delay) {
            this.command = command;
            this.delay = delay;
        }
    }
}
