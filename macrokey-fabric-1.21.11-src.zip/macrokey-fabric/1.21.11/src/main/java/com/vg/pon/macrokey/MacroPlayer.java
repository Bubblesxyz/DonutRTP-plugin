package com.vg.pon.macrokey;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.client.Minecraft;

public class MacroPlayer {
    private static final List<Execution> activeExecutions = new LinkedList<>();

    public static void tick() {
        if (activeExecutions.isEmpty()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            activeExecutions.clear();
            return;
        }
        Iterator<Execution> it = activeExecutions.iterator();
        while (it.hasNext()) {
            Execution exec = it.next();
            exec.tick(mc);
            if (exec.isFinished()) {
                it.remove();
            }
        }
    }

    public static void start(MacroData macro) {
        if (macro.steps.isEmpty()) {
            return;
        }
        activeExecutions.add(new Execution(macro));
    }

    private static class Execution {
        private final List<MacroData.MacroStep> steps;
        private int currentStepIndex = 0;
        private int tickCounter = 0;

        Execution(MacroData macro) {
            this.steps = new ArrayList<>(macro.steps);
        }

        void tick(Minecraft mc) {
            if (currentStepIndex >= steps.size()) {
                return;
            }
            MacroData.MacroStep step = steps.get(currentStepIndex);
            if (tickCounter >= step.delay) {
                send(mc, step.command);
                currentStepIndex++;
                tickCounter = 0;
            } else {
                tickCounter++;
            }
        }

        private void send(Minecraft mc, String cmd) {
            if (cmd == null || cmd.isEmpty()) {
                return;
            }
            if (cmd.startsWith("/")) {
                mc.player.connection.sendCommand(cmd.substring(1));
            } else {
                mc.player.connection.sendChat(cmd);
            }
        }

        boolean isFinished() {
            return currentStepIndex >= steps.size();
        }
    }
}
