package com.vg.pon.macrokey;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.HashSet;
import java.util.Set;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class Macrokey implements ClientModInitializer {
    public static final String MODID = "macrokey";
    public static KeyMapping OPEN_GUI_KEY;
    private static final Set<Integer> held = new HashSet<>();

    @Override
    public void onInitializeClient() {
        MacroConfig.load();
        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MODID, "main"));
        OPEN_GUI_KEY = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.macrokey.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, category));
        ClientTickEvents.END_CLIENT_TICK.register(Macrokey::onTick);
    }

    private static void onTick(Minecraft mc) {
        MacroPlayer.tick();

        boolean canFire = mc.player != null && mc.screen == null;
        if (canFire) {
            while (OPEN_GUI_KEY.consumeClick()) {
                mc.setScreen(new MacroScreen(null));
                return;
            }
        }

        // Poll bound keys each tick and fire on press (rising edge).
        // glfwGetCurrentContext() is the game window on the render thread, so this works on every game version.
        long window = GLFW.glfwGetCurrentContext();
        Set<Integer> down = new HashSet<>();
        if (window != 0L) {
            for (MacroData m : MacroConfig.macros) {
                if (m.keyCode >= 0 && GLFW.glfwGetKey(window, m.keyCode) == GLFW.GLFW_PRESS) {
                    down.add(m.keyCode);
                }
            }
        }
        if (canFire) {
            for (MacroData m : MacroConfig.macros) {
                if (m.active && down.contains(m.keyCode) && !held.contains(m.keyCode)) {
                    MacroPlayer.start(m);
                }
            }
        }
        held.clear();
        held.addAll(down);
    }
}
