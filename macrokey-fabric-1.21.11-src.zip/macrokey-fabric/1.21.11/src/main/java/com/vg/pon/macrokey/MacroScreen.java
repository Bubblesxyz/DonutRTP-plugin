package com.vg.pon.macrokey;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSelectionList;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ContainerObjectSelectionList;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class MacroScreen extends Screen {
    private final Screen parent;
    private MacroListWidget listWidget;
    private List<Component> tooltipToRender = null;

    public MacroScreen(Screen parent) {
        super(Component.literal("Macro Manager"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int btnWidth = 150;
        int spacing = 10;
        int totalWidth = btnWidth * 2 + spacing;
        int startX = (this.width - totalWidth) / 2;
        this.addRenderableWidget(Button.builder(Component.literal("Create New Macro"), btn -> {
            MacroData newMacro = new MacroData("New Macro", -1);
            MacroConfig.macros.add(newMacro);
            this.minecraft.setScreen(new MacroEditScreen(this, newMacro));
        }).bounds(startX, this.height - 30, btnWidth, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Close"), btn -> this.onClose())
                .bounds(startX + btnWidth + spacing, this.height - 30, btnWidth, 20).build());
        this.listWidget = new MacroListWidget(this.minecraft, this.width, this.height - 80, 40, 30);
        this.addRenderableWidget(this.listWidget);
        this.rebuildList();
    }

    private void rebuildList() {
        this.listWidget.reset();
        for (MacroData macro : MacroConfig.macros) {
            this.listWidget.addMacro(macro);
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.tooltipToRender = null;
        g.fill(0, 0, this.width, this.height, 0x90000000);
        super.render(g, mouseX, mouseY, partialTick);
        g.drawCenteredString(this.font, "Macro List", this.width / 2, 15, 0xFFFFFFFF);
        if (this.tooltipToRender != null) {
            drawTip(g, this.tooltipToRender, mouseX, mouseY);
        }
    }

    /** Small hand-drawn tooltip box (only uses basic drawing calls, so it works on every game version). */
    private void drawTip(GuiGraphics g, List<Component> lines, int mx, int my) {
        int w = 0;
        for (Component c : lines) w = Math.max(w, this.font.width(c));
        int h = lines.size() * 10;
        int x = mx + 12;
        int y = my - 12;
        if (x + w + 8 > this.width) x = mx - w - 20;
        if (y + h + 8 > this.height) y = this.height - h - 8;
        if (y < 6) y = 6;
        g.fill(x - 4, y - 4, x + w + 4, y + h + 2, 0xF0100010);
        g.fill(x - 4, y - 4, x + w + 4, y - 3, 0xFF5000FF);
        g.fill(x - 4, y + h + 1, x + w + 4, y + h + 2, 0xFF5000FF);
        g.fill(x - 4, y - 4, x - 3, y + h + 2, 0xFF5000FF);
        g.fill(x + w + 3, y - 4, x + w + 4, y + h + 2, 0xFF5000FF);
        for (int i = 0; i < lines.size(); i++) {
            g.drawString(this.font, lines.get(i), x, y + i * 10, 0xFFFFFFFF, true);
        }
    }

    @Override
    public void onClose() {
        MacroConfig.save();
        if (this.minecraft != null) {
            this.minecraft.setScreen(this.parent);
        }
    }

    class MacroListWidget extends ContainerObjectSelectionList<MacroEntry> {
        public MacroListWidget(Minecraft mc, int width, int height, int y0, int itemHeight) {
            super(mc, width, height, y0, itemHeight);
        }

        public void addMacro(MacroData data) {
            this.addEntry(new MacroEntry(data));
        }

        public void reset() {
            this.clearEntries();
        }

        @Override
        public int getRowWidth() {
            return 320;
        }
    }

    class MacroEntry extends ContainerObjectSelectionList.Entry<MacroEntry> {
        private final MacroData data;
        private final Button editBtn;
        private final Button deleteBtn;
        private final Button toggleBtn;

        public MacroEntry(MacroData data) {
            this.data = data;
            this.editBtn = Button.builder(Component.literal("Edit"),
                    btn -> Minecraft.getInstance().setScreen(new MacroEditScreen(MacroScreen.this, data)))
                    .bounds(0, 0, 40, 20).build();
            this.toggleBtn = Button.builder(Component.literal(data.active ? "ON" : "OFF"), btn -> {
                data.active = !data.active;
                btn.setMessage(Component.literal(data.active ? "ON" : "OFF"));
                btn.setFocused(false);
            }).bounds(0, 0, 35, 20).build();
            this.deleteBtn = Button.builder(Component.literal("Del"), btn -> {
                MacroConfig.macros.remove(data);
                MacroScreen.this.rebuildList();
            }).bounds(0, 0, 35, 20).build();
        }

        @Override
        public void renderContent(GuiGraphics graphics, int mouseX, int mouseY, boolean hovered, float partialTick) {
            int top = this.getContentY();
            int left = this.getContentX();
            int width = this.getContentWidth();
            int height = this.getContentHeight();
            var font = Minecraft.getInstance().font;
            String text = data.name.length() > 15 ? data.name.substring(0, 15) + "..." : data.name;
            graphics.drawString(font, text, left + 5, top + 8, 0xFFFFFFFF, false);
            String keyName = "[" + data.getKeyName() + "]";
            graphics.drawString(font, keyName, left + 150 - font.width(keyName) / 2, top + 8, 0xFFFFAA00, false);
            int rightEdge = left + width;
            deleteBtn.setX(rightEdge - 35);
            deleteBtn.setY(top + 2);
            toggleBtn.setX(rightEdge - 75);
            toggleBtn.setY(top + 2);
            editBtn.setX(rightEdge - 120);
            editBtn.setY(top + 2);
            editBtn.render(graphics, mouseX, mouseY, partialTick);
            toggleBtn.render(graphics, mouseX, mouseY, partialTick);
            deleteBtn.render(graphics, mouseX, mouseY, partialTick);
            if (hovered && mouseX >= left && mouseX <= left + 150 && mouseY >= top && mouseY <= top + height) {
                List<Component> tip = new ArrayList<>();
                tip.add(Component.literal(data.name).withStyle(ChatFormatting.BOLD, ChatFormatting.YELLOW));
                tip.add(Component.literal("Key: " + data.getKeyName()).withStyle(ChatFormatting.GRAY));
                tip.add(Component.empty());
                tip.add(Component.literal("Steps:").withStyle(ChatFormatting.UNDERLINE));
                int limit = Math.min(data.steps.size(), 4);
                for (int i = 0; i < limit; i++) {
                    MacroData.MacroStep s = data.steps.get(i);
                    String cmd = s.command.isEmpty() ? "<empty>"
                            : (s.command.length() > 20 ? s.command.substring(0, 18) + ".." : s.command);
                    tip.add(Component.literal("- " + cmd + " (" + s.delay + "t)").withStyle(ChatFormatting.WHITE));
                }
                if (data.steps.size() > 4) {
                    tip.add(Component.literal("... " + (data.steps.size() - 4) + " more").withStyle(ChatFormatting.DARK_GRAY));
                }
                MacroScreen.this.tooltipToRender = tip;
            }
        }

        @Override
        public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
            return editBtn.mouseClicked(event, doubleClick) || toggleBtn.mouseClicked(event, doubleClick)
                    || deleteBtn.mouseClicked(event, doubleClick);
        }

        @Override
        public List<? extends GuiEventListener> children() {
            return List.of(editBtn, toggleBtn, deleteBtn);
        }

        @Override
        public List<? extends NarratableEntry> narratables() {
            return List.of(editBtn, toggleBtn, deleteBtn);
        }
    }
}
