package com.vg.pon.macrokey;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;

public class MacroConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("macrokey_binds.json");
    public static List<MacroData> macros = new ArrayList<>();

    public static void load() {
        if (!Files.exists(CONFIG_PATH)) {
            save();
            return;
        }
        try (BufferedReader reader = Files.newBufferedReader(CONFIG_PATH)) {
            List<MacroData> loaded = GSON.fromJson(reader, new TypeToken<List<MacroData>>() {}.getType());
            macros = loaded != null ? loaded : new ArrayList<>();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            try (BufferedWriter writer = Files.newBufferedWriter(CONFIG_PATH)) {
                GSON.toJson(macros, writer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
