# MacroKey for Minecraft 1.21.11 (Fabric)

Build: upload this folder's contents to a GitHub repository (keep the `.github` folder at the top),
open the Actions tab, run "build", then download the artifact `macrokey-fabric-1.21.11`.
Use the jar WITHOUT "-sources" in its name. Needs Fabric Loader 0.18+ and Fabric API for 1.21.11.
