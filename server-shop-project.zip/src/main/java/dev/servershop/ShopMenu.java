package dev.servershop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Builds the shop screens and handles clicks. */
final class ShopMenu {
    private final ShopPlugin plugin;

    ShopMenu(ShopPlugin plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------- screens

    void openMain(Player player) {
        ShopHolder holder = new ShopHolder(ShopHolder.Type.MAIN, null, 0, null);
        Inventory inventory = Bukkit.createInventory(holder, 27, Component.text("SHOP"));
        holder.setInventory(inventory);

        for (Category category : plugin.categories()) {
            if (category.menuSlot() < 0 || category.menuSlot() >= 27) {
                continue;
            }
            inventory.setItem(category.menuSlot(), icon(category.icon(), 1,
                    Component.text(category.name(), NamedTextColor.AQUA, TextDecoration.BOLD),
                    Component.text("Click to view " + category.view() + " Shop", NamedTextColor.WHITE)));
        }
        player.openInventory(inventory);
    }

    void openCategory(Player player, Category category, int page) {
        if (category.items().isEmpty()) {
            player.sendMessage(Component.text("The " + category.view() + " shop isn't stocked yet.", NamedTextColor.RED));
            return;
        }

        int perPage = category.slots().size();
        int pages = Math.max(1, (category.items().size() + perPage - 1) / perPage);
        int current = Math.max(0, Math.min(page, pages - 1));

        ShopHolder holder = new ShopHolder(ShopHolder.Type.CATEGORY, category, current, null);
        Inventory inventory = Bukkit.createInventory(holder, category.rows() * 9, Component.text(category.title()));
        holder.setInventory(inventory);

        for (int i = 0; i < perPage; i++) {
            int index = current * perPage + i;
            if (index >= category.items().size()) {
                break;
            }
            ShopItem item = category.items().get(index);
            ItemStack stack = item.create(1);
            ItemMeta meta = stack.getItemMeta();
            List<Component> lore = new ArrayList<>();
            lore.add(plain(Component.text("Price: ", NamedTextColor.WHITE)
                    .append(Component.text(Money.format(item.price() * stackSize(item.material())), NamedTextColor.AQUA))));
            lore.add(plain(Component.text("Click to buy", NamedTextColor.GREEN)));
            meta.lore(lore);
            stack.setItemMeta(meta);
            inventory.setItem(category.slots().get(i), stack);
        }

        int nav = (category.rows() - 1) * 9;
        if (current > 0) {
            inventory.setItem(nav + 3, icon(Material.ARROW, 1,
                    Component.text("PREVIOUS PAGE", NamedTextColor.AQUA, TextDecoration.BOLD),
                    Component.text("Click to go to the previous page", NamedTextColor.WHITE)));
        }
        inventory.setItem(nav + 4, icon(Material.RED_STAINED_GLASS_PANE, 1,
                Component.text("BACK", NamedTextColor.RED, TextDecoration.BOLD),
                Component.text("Click to go back", NamedTextColor.WHITE)));
        if (current < pages - 1) {
            inventory.setItem(nav + 5, icon(Material.ARROW, 1,
                    Component.text("NEXT PAGE", NamedTextColor.AQUA, TextDecoration.BOLD),
                    Component.text("Click to go to the next page", NamedTextColor.WHITE)));
        }
        player.openInventory(inventory);
    }

    private void openBuy(Player player, Category category, int page, ShopItem item) {
        ShopHolder holder = new ShopHolder(ShopHolder.Type.BUY, category, page, item);
        Inventory inventory = Bukkit.createInventory(holder, 27, Component.text("BUYING " + item.displayName()));
        holder.setInventory(inventory);

        int stack = stackSize(item.material());
        double price = item.price() * stack;

        ItemStack shown = item.create(stack);
        ItemMeta meta = shown.getItemMeta();
        meta.lore(List.of(plain(priceLine(price))));
        shown.setItemMeta(meta);
        inventory.setItem(13, shown);

        inventory.setItem(21, icon(Material.RED_STAINED_GLASS_PANE, 1,
                Component.text("CANCEL", NamedTextColor.RED, TextDecoration.BOLD),
                Component.text("Click to cancel", NamedTextColor.WHITE)));
        inventory.setItem(22, icon(Material.BUNDLE, 1,
                Component.text("BUY MORE", NamedTextColor.GREEN, TextDecoration.BOLD),
                Component.text("Can hold a mixed stack of items", NamedTextColor.WHITE)));
        inventory.setItem(23, icon(Material.LIME_STAINED_GLASS_PANE, 1,
                Component.text("CONFIRM", NamedTextColor.GREEN, TextDecoration.BOLD),
                Component.text("Click to confirm", NamedTextColor.WHITE),
                priceLine(price)));
        player.openInventory(inventory);
    }

    private void openStacks(Player player, Category category, int page, ShopItem item) {
        ShopHolder holder = new ShopHolder(ShopHolder.Type.STACKS, category, page, item);
        Inventory inventory = Bukkit.createInventory(holder, 27,
                Component.text("BUYING STACKS OF " + item.displayName()));
        holder.setInventory(inventory);

        int stack = stackSize(item.material());
        for (int i = 1; i <= 9; i++) {
            double price = item.price() * stack * i;
            ItemStack option = item.create(stack);
            ItemMeta optionMeta = option.getItemMeta();
            optionMeta.displayName(plain(Component.text("Buy " + i + (i == 1 ? " stack" : " stacks"), NamedTextColor.GREEN)));
            optionMeta.lore(List.of(plain(priceLine(price))));
            option.setItemMeta(optionMeta);
            inventory.setItem(8 + i, option);
        }
        inventory.setItem(22, icon(Material.RED_STAINED_GLASS_PANE, 1,
                Component.text("CANCEL", NamedTextColor.RED, TextDecoration.BOLD),
                Component.text("Click to cancel", NamedTextColor.WHITE)));
        player.openInventory(inventory);
    }

    // ----------------------------------------------------------------- clicks

    void handleClick(Player player, ShopHolder holder, int slot) {
        ShopHolder.Type type = holder.type();

        if (type == ShopHolder.Type.MAIN) {
            for (Category category : plugin.categories()) {
                if (category.menuSlot() == slot) {
                    openCategory(player, category, 0);
                    return;
                }
            }
            return;
        }

        Category category = holder.category();

        if (type == ShopHolder.Type.CATEGORY) {
            int perPage = category.slots().size();
            int pages = Math.max(1, (category.items().size() + perPage - 1) / perPage);
            int nav = (category.rows() - 1) * 9;

            if (slot == nav + 3 && holder.page() > 0) {
                openCategory(player, category, holder.page() - 1);
            } else if (slot == nav + 4) {
                openMain(player);
            } else if (slot == nav + 5 && holder.page() < pages - 1) {
                openCategory(player, category, holder.page() + 1);
            } else {
                int position = category.slots().indexOf(slot);
                int index = holder.page() * perPage + position;
                if (position >= 0 && index < category.items().size()) {
                    openBuy(player, category, holder.page(), category.items().get(index));
                }
            }
            return;
        }

        if (type == ShopHolder.Type.BUY) {
            if (slot == 21) {
                openCategory(player, category, holder.page());
            } else if (slot == 22) {
                openStacks(player, category, holder.page(), holder.item());
            } else if (slot == 23) {
                buy(player, holder.item(), 1);
            }
            return;
        }

        if (type == ShopHolder.Type.STACKS) {
            if (slot == 22) {
                openBuy(player, category, holder.page(), holder.item());
            } else if (slot >= 9 && slot <= 17) {
                buy(player, holder.item(), slot - 8);
            }
        }
    }

    // ----------------------------------------------------------------- buying

    private void buy(Player player, ShopItem item, int stacks) {
        if (!plugin.money().ready()) {
            player.sendMessage(Component.text("The shop can't reach the economy. Tell an admin (needs Vault + an economy plugin).",
                    NamedTextColor.RED));
            return;
        }

        int stackSize = stackSize(item.material());
        int amount = stackSize * stacks;
        double cost = item.price() * amount;

        if (!plugin.money().has(player, cost)) {
            player.sendMessage(Component.text("You need " + Money.format(cost) + " to buy that.", NamedTextColor.RED));
            return;
        }
        if (freeSpace(player, item) < amount) {
            player.sendMessage(Component.text("Not enough inventory space.", NamedTextColor.RED));
            return;
        }
        if (!plugin.money().withdraw(player, cost)) {
            player.sendMessage(Component.text("The payment failed.", NamedTextColor.RED));
            return;
        }

        int remaining = amount;
        while (remaining > 0) {
            int part = Math.min(remaining, stackSize);
            Map<Integer, ItemStack> left = player.getInventory().addItem(item.create(part));
            for (ItemStack extra : left.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), extra);
            }
            remaining -= part;
        }

        player.closeInventory();
        player.sendMessage(Component.text("You bought " + amount + "x " + item.displayName()
                + " for " + Money.format(cost) + ".", NamedTextColor.GREEN));
    }

    private int freeSpace(Player player, ShopItem item) {
        int max = item.material().getMaxStackSize();
        ItemStack plain = item.create(1);
        int space = 0;
        for (ItemStack slot : player.getInventory().getStorageContents()) {
            if (slot == null || slot.getType().isAir()) {
                space += max;
            } else if (slot.isSimilar(plain)) {
                space += Math.max(0, max - slot.getAmount());
            }
        }
        return space;
    }

    // ---------------------------------------------------------------- helpers

    private static int stackSize(Material material) {
        return Math.max(1, Math.min(64, material.getMaxStackSize()));
    }

    private static String niceName(Material material) {
        StringBuilder builder = new StringBuilder();
        for (String part : material.name().toLowerCase(Locale.ROOT).split("_")) {
            if (part.isEmpty()) {
                continue;
            }
            if (builder.length() > 0) {
                builder.append(' ');
            }
            builder.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return builder.toString();
    }

    private static Component priceLine(double price) {
        return Component.text("Price: ", NamedTextColor.WHITE)
                .append(Component.text(Money.format(price), NamedTextColor.AQUA));
    }

    private static Component plain(Component component) {
        return component.decoration(TextDecoration.ITALIC, false);
    }

    private static ItemStack icon(Material material, int amount, Component name, Component... lore) {
        ItemStack stack = new ItemStack(material, amount);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(plain(name));
        List<Component> lines = new ArrayList<>();
        for (Component line : lore) {
            lines.add(plain(line));
        }
        meta.lore(lines);
        stack.setItemMeta(meta);
        return stack;
    }
}
