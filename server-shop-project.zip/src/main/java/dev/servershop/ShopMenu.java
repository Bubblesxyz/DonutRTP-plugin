package dev.servershop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Builds the shop screens and handles clicks. */
final class ShopMenu {
    /** Columns used for a row holding N items - always symmetric, so every screen looks even. */
    private static final int[][] ROW_COLUMNS = {
            {},
            {4},
            {3, 5},
            {3, 4, 5},
            {2, 3, 5, 6},
            {2, 3, 4, 5, 6},
            {1, 2, 3, 5, 6, 7},
            {1, 2, 3, 4, 5, 6, 7}
    };

    private final ShopPlugin plugin;

    ShopMenu(ShopPlugin plugin) {
        this.plugin = plugin;
    }

    // ----------------------------------------------------------------- layout

    /** Slots for `count` items, starting at inventory row 1, centered, balanced rows of up to 7. */
    private static int[] layout(int count) {
        int[] slots = new int[count];
        if (count == 0) {
            return slots;
        }
        int rows = (count + 6) / 7;
        int base = count / rows;
        int extra = count % rows;
        int index = 0;
        for (int row = 0; row < rows; row++) {
            int inRow = base + (row < extra ? 1 : 0);
            for (int column : ROW_COLUMNS[inRow]) {
                slots[index++] = (1 + row) * 9 + column;
            }
        }
        return slots;
    }

    private static int itemRows(int count) {
        return Math.max(1, (count + 6) / 7);
    }

    private static int pageCount(Category category) {
        return Math.max(1, (category.items().size() + category.perPage() - 1) / category.perPage());
    }

    private static int itemsOnPage(Category category, int page) {
        int start = page * category.perPage();
        return Math.max(0, Math.min(category.perPage(), category.items().size() - start));
    }

    // ---------------------------------------------------------------- screens

    void openMain(Player player) {
        List<Category> categories = plugin.categories();
        int[] slots = layout(categories.size());
        int size = Math.max(27, (itemRows(categories.size()) + 1) * 9);

        ShopHolder holder = new ShopHolder(ShopHolder.Type.MAIN, null, 0, null);
        Inventory inventory = Bukkit.createInventory(holder, size, Component.text("SHOP"));
        holder.setInventory(inventory);

        for (int i = 0; i < categories.size(); i++) {
            Category category = categories.get(i);
            inventory.setItem(slots[i], icon(category.icon(), 1,
                    Component.text(category.name(), NamedTextColor.GREEN),
                    Component.text("Click to view the " + category.view().toLowerCase(Locale.ROOT) + " shop",
                            NamedTextColor.WHITE)));
        }
        player.openInventory(inventory);
    }

    void openCategory(Player player, Category category, int page) {
        if (category.items().isEmpty()) {
            player.sendMessage(Component.text("The " + category.view() + " shop isn't stocked yet.", NamedTextColor.RED));
            return;
        }

        int pages = pageCount(category);
        int current = Math.max(0, Math.min(page, pages - 1));
        int count = itemsOnPage(category, current);
        int rows = itemRows(count) + 2;
        int[] slots = layout(count);

        ShopHolder holder = new ShopHolder(ShopHolder.Type.CATEGORY, category, current, null);
        Inventory inventory = Bukkit.createInventory(holder, rows * 9, Component.text(category.title()));
        holder.setInventory(inventory);

        for (int i = 0; i < count; i++) {
            ShopItem item = category.items().get(current * category.perPage() + i);
            ItemStack stack = item.create(1);
            ItemMeta meta = stack.getItemMeta();
            List<Component> lore = new ArrayList<>();
            lore.add(priceLine(item.price()));
            lore.add(plain(Component.text("Click to buy", NamedTextColor.GREEN)));
            meta.lore(lore);
            stack.setItemMeta(meta);
            inventory.setItem(slots[i], stack);
        }

        int nav = (rows - 1) * 9;
        if (current > 0) {
            inventory.setItem(nav + 3, icon(Material.ARROW, 1,
                    Component.text("PREVIOUS PAGE", NamedTextColor.AQUA),
                    Component.text("Click to go to the previous page", NamedTextColor.WHITE)));
        }
        inventory.setItem(nav + 4, icon(Material.RED_STAINED_GLASS_PANE, 1,
                Component.text("BACK", NamedTextColor.RED),
                Component.text("Click to go back", NamedTextColor.WHITE)));
        if (current < pages - 1) {
            inventory.setItem(nav + 5, icon(Material.ARROW, 1,
                    Component.text("NEXT PAGE", NamedTextColor.AQUA),
                    Component.text("Click to go to the next page", NamedTextColor.WHITE)));
        }
        player.openInventory(inventory);
    }

    private void openBuy(Player player, Category category, int page, ShopItem item) {
        ShopHolder holder = new ShopHolder(ShopHolder.Type.BUY, category, page, item);
        Inventory inventory = Bukkit.createInventory(holder, 27, Component.text("BUYING " + item.displayName()));
        holder.setInventory(inventory);

        ItemStack shown = item.create(1);
        ItemMeta meta = shown.getItemMeta();
        meta.lore(List.of(priceLine(item.price())));
        shown.setItemMeta(meta);
        inventory.setItem(13, shown);

        inventory.setItem(21, icon(Material.RED_STAINED_GLASS_PANE, 1,
                Component.text("CANCEL", NamedTextColor.RED),
                Component.text("Click to cancel", NamedTextColor.WHITE)));
        inventory.setItem(22, icon(Material.BUNDLE, 1,
                Component.text("BUY MORE", NamedTextColor.GREEN),
                Component.text("Can hold a mixed stack of items", NamedTextColor.WHITE)));
        inventory.setItem(23, icon(Material.LIME_STAINED_GLASS_PANE, 1,
                Component.text("CONFIRM", NamedTextColor.GREEN),
                Component.text("Click to confirm", NamedTextColor.WHITE),
                priceText(item.price())));
        player.openInventory(inventory);
    }

    private void openStacks(Player player, Category category, int page, ShopItem item) {
        ShopHolder holder = new ShopHolder(ShopHolder.Type.STACKS, category, page, item);
        Inventory inventory = Bukkit.createInventory(holder, 27,
                Component.text("BUYING STACKS OF " + item.displayName()));
        holder.setInventory(inventory);

        int stack = stackSize(item.material());
        for (int i = 1; i <= 9; i++) {
            ItemStack option = item.create(stack);
            ItemMeta optionMeta = option.getItemMeta();
            optionMeta.displayName(plain(Component.text("Buy " + i + (i == 1 ? " stack" : " stacks"), NamedTextColor.GREEN)));
            optionMeta.lore(List.of(priceLine(cost(item, stack * i))));
            option.setItemMeta(optionMeta);
            inventory.setItem(8 + i, option);
        }
        inventory.setItem(22, icon(Material.RED_STAINED_GLASS_PANE, 1,
                Component.text("CANCEL", NamedTextColor.RED),
                Component.text("Click to cancel", NamedTextColor.WHITE)));
        player.openInventory(inventory);
    }

    // ----------------------------------------------------------------- clicks

    void handleClick(Player player, ShopHolder holder, int slot) {
        ShopHolder.Type type = holder.type();

        if (type == ShopHolder.Type.MAIN) {
            List<Category> categories = plugin.categories();
            int[] slots = layout(categories.size());
            for (int i = 0; i < slots.length; i++) {
                if (slots[i] == slot) {
                    openCategory(player, categories.get(i), 0);
                    return;
                }
            }
            return;
        }

        Category category = holder.category();

        if (type == ShopHolder.Type.CATEGORY) {
            int pages = pageCount(category);
            int count = itemsOnPage(category, holder.page());
            int nav = (itemRows(count) + 1) * 9;

            if (slot == nav + 3 && holder.page() > 0) {
                openCategory(player, category, holder.page() - 1);
            } else if (slot == nav + 4) {
                openMain(player);
            } else if (slot == nav + 5 && holder.page() < pages - 1) {
                openCategory(player, category, holder.page() + 1);
            } else {
                int[] slots = layout(count);
                for (int i = 0; i < slots.length; i++) {
                    if (slots[i] == slot) {
                        openBuy(player, category, holder.page(),
                                category.items().get(holder.page() * category.perPage() + i));
                        return;
                    }
                }
            }
            return;
        }

        if (type == ShopHolder.Type.BUY) {
            if (slot == 21) {
                openCategory(player, category, holder.page());
            } else if (slot == 22) {
                openStacks(player, category, holder.page(), holder.item());
            } else if (slot == 23) {
                buy(player, holder.item(), 1);
            }
            return;
        }

        if (type == ShopHolder.Type.STACKS) {
            if (slot == 22) {
                openBuy(player, category, holder.page(), holder.item());
            } else if (slot >= 9 && slot <= 17) {
                buy(player, holder.item(), stackSize(holder.item().material()) * (slot - 8));
            }
        }
    }

    // ----------------------------------------------------------------- buying

    /** Buys `amount` single items. The menu stays open on the same screen. */
    private void buy(Player player, ShopItem item, int amount) {
        if (!plugin.money().ready()) {
            player.sendMessage(Component.text("The shop can't reach the economy. Tell an admin (needs Vault + an economy plugin).",
                    NamedTextColor.RED));
            return;
        }

        double cost = cost(item, amount);

        if (!plugin.money().has(player, cost)) {
            player.sendMessage(Component.text("You need " + Money.format(cost) + " to buy that.", NamedTextColor.RED));
            return;
        }
        if (freeSpace(player, item) < amount) {
            player.sendMessage(Component.text("Not enough inventory space.", NamedTextColor.RED));
            return;
        }
        if (!plugin.money().withdraw(player, cost)) {
            player.sendMessage(Component.text("The payment failed.", NamedTextColor.RED));
            return;
        }

        int stackSize = stackSize(item.material());
        int remaining = amount;
        while (remaining > 0) {
            int part = Math.min(remaining, stackSize);
            Map<Integer, ItemStack> left = player.getInventory().addItem(item.create(part));
            for (ItemStack extra : left.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), extra);
            }
            remaining -= part;
        }

        player.sendMessage(Component.text("You bought " + amount + "x " + item.displayName()
                + " for " + Money.format(cost) + ".", NamedTextColor.GREEN));
    }

    private int freeSpace(Player player, ShopItem item) {
        int max = item.material().getMaxStackSize();
        ItemStack proto = item.create(1);
        int space = 0;
        for (ItemStack slot : player.getInventory().getStorageContents()) {
            if (slot == null || slot.getType().isAir()) {
                space += max;
            } else if (slot.isSimilar(proto)) {
                space += Math.max(0, max - slot.getAmount());
            }
        }
        return space;
    }

    // ---------------------------------------------------------------- helpers

    private static double cost(ShopItem item, int amount) {
        return Math.round(item.price() * amount * 100.0) / 100.0;
    }

    private static int stackSize(Material material) {
        return Math.max(1, Math.min(64, material.getMaxStackSize()));
    }

    private static Component priceText(double price) {
        return Component.text("Price: ", NamedTextColor.WHITE)
                .append(Component.text(Money.format(price), NamedTextColor.AQUA));
    }

    private static Component priceLine(double price) {
        return plain(priceText(price));
    }

    private static Component plain(Component component) {
        return component.decoration(TextDecoration.ITALIC, false);
    }

    private static ItemStack icon(Material material, int amount, Component name, Component... lore) {
        ItemStack stack = new ItemStack(material, amount);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(plain(name));
        List<Component> lines = new ArrayList<>();
        for (Component line : lore) {
            lines.add(plain(line));
        }
        meta.lore(lines);
        stack.setItemMeta(meta);
        return stack;
    }
}
