package dev.servershop;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** Marks our inventories so clicks in them can be recognised and cancelled. */
final class ShopHolder implements InventoryHolder {
    enum Type { MAIN, CATEGORY, BUY, STACKS }

    private final Type type;
    private final Category category;
    private final int page;
    private final ShopItem item;
    private Inventory inventory;

    ShopHolder(Type type, Category category, int page, ShopItem item) {
        this.type = type;
        this.category = category;
        this.page = page;
        this.item = item;
    }

    Type type() {
        return type;
    }

    Category category() {
        return category;
    }

    int page() {
        return page;
    }

    ShopItem item() {
        return item;
    }

    void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
