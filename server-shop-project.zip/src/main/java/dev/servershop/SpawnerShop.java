package dev.servershop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** The Spawners menu. Read from spawners.yml, paid with in-game money (Vault). */
final class SpawnerShop {
    private static final LegacyComponentSerializer LEGACY =
            LegacyComponentSerializer.builder().character('&').hexColors().build();

    private record Entry(String id, int slot, Material material, String name, String color,
                         double price, List<String> commands, List<String> description) {
    }

    private final ShopPlugin plugin;
    private final List<Entry> entries = new ArrayList<>();

    private Material buttonMaterial = Material.SPAWNER;
    private String buttonName = "&6&lSPAWNERS";
    private List<String> buttonLore = new ArrayList<>();
    private boolean glow;

    private String title = "Spawners";
    private int rows = 3;
    private int backSlot = 18;
    private List<String> affordable = new ArrayList<>();
    private List<String> tooExpensive = new ArrayList<>();

    SpawnerShop(ShopPlugin plugin, File file) {
        this.plugin = plugin;
        load(file);
    }

    boolean enabled() {
        return !entries.isEmpty();
    }

    // ------------------------------------------------------------------ config

    private void load(File file) {
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = yaml.getConfigurationSection("spawners");
        if (root == null) {
            plugin.getLogger().warning("spawners.yml has no 'spawners' section.");
            return;
        }

        glow = root.getBoolean("glow", false);

        ConfigurationSection button = root.getConfigurationSection("button");
        if (button != null) {
            buttonMaterial = material(button.getString("material"), Material.SPAWNER);
            buttonName = button.getString("name", buttonName);
            buttonLore = button.getStringList("description");
        }

        ConfigurationSection menu = root.getConfigurationSection("menu");
        if (menu != null) {
            title = menu.getString("title", title);
            rows = Math.max(1, Math.min(6, menu.getInt("rows", 3)));
            backSlot = menu.getInt("back-slot", 18);
        }

        ConfigurationSection lore = root.getConfigurationSection("entry-lore");
        if (lore != null) {
            affordable = lore.getStringList("affordable");
            tooExpensive = lore.getStringList("too-expensive");
        }

        ConfigurationSection list = root.getConfigurationSection("entries");
        if (list == null) {
            return;
        }
        for (String id : list.getKeys(false)) {
            ConfigurationSection section = list.getConfigurationSection(id);
            if (section == null) {
                continue;
            }
            double price = section.getDouble("price", 0);
            if (price <= 0) {
                plugin.getLogger().warning("Spawner " + id + " has no valid price, skipped.");
                continue;
            }
            entries.add(new Entry(
                    id,
                    section.getInt("slot", 10),
                    material(section.getString("material"), Material.SPAWNER),
                    section.getString("name", id),
                    section.getString("color", "&f"),
                    price,
                    section.getStringList("commands"),
                    section.getStringList("description")));
        }
        plugin.getLogger().info("Loaded " + entries.size() + " spawners.");
    }

    private static Material material(String name, Material fallback) {
        Material material = name == null ? null : Material.matchMaterial(name);
        return material == null ? fallback : material;
    }

    // ------------------------------------------------------------------- items

    private static Component line(String text) {
        return LEGACY.deserialize(text).decoration(TextDecoration.ITALIC, false);
    }

    /** The icon on the main shop screen. */
    ItemStack button() {
        ItemStack stack = new ItemStack(buttonMaterial);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(line(buttonName));
        List<Component> lore = new ArrayList<>();
        for (String text : buttonLore) {
            lore.add(line(text));
        }
        meta.lore(lore);
        if (glow) {
            meta.setEnchantmentGlintOverride(true);
        }
        stack.setItemMeta(meta);
        return stack;
    }

    private ItemStack entryItem(Entry entry, boolean canAfford) {
        ItemStack stack = new ItemStack(entry.material());
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(line(entry.name()));

        List<Component> lore = new ArrayList<>();
        for (String template : canAfford ? affordable : tooExpensive) {
            if (template.contains("%description%")) {
                for (String descriptionLine : entry.description()) {
                    lore.add(line(descriptionLine));
                }
                continue;
            }
            lore.add(line(template
                    .replace("%color%", entry.color())
                    .replace("%price%", Money.format(entry.price()))));
        }
        meta.lore(lore);
        stack.setItemMeta(meta);
        return stack;
    }

    // -------------------------------------------------------------------- menu

    void open(Player player) {
        ShopHolder holder = new ShopHolder(ShopHolder.Type.SPAWNERS, null, 0, null);
        Inventory inventory = Bukkit.createInventory(holder, rows * 9, Component.text(title));
        holder.setInventory(inventory);
        fill(inventory, player);
        player.openInventory(inventory);
    }

    private void fill(Inventory inventory, Player player) {
        inventory.clear();
        boolean economy = plugin.money().ready();
        for (Entry entry : entries) {
            if (entry.slot() < 0 || entry.slot() >= inventory.getSize()) {
                continue;
            }
            boolean canAfford = economy && plugin.money().has(player, entry.price());
            inventory.setItem(entry.slot(), entryItem(entry, canAfford));
        }

        ItemStack back = new ItemStack(Material.RED_STAINED_GLASS_PANE);
        ItemMeta meta = back.getItemMeta();
        meta.displayName(Component.text("BACK", NamedTextColor.RED).decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text("Click to go back", NamedTextColor.WHITE).decoration(TextDecoration.ITALIC, false)));
        back.setItemMeta(meta);
        if (backSlot >= 0 && backSlot < inventory.getSize()) {
            inventory.setItem(backSlot, back);
        }
    }

    void handleClick(Player player, ShopHolder holder, int slot) {
        if (slot == backSlot) {
            plugin.menu().openMain(player);
            return;
        }
        for (Entry entry : entries) {
            if (entry.slot() == slot) {
                buy(player, entry);
                fill(holder.getInventory(), player);
                return;
            }
        }
    }

    // ------------------------------------------------------------------ buying

    private void buy(Player player, Entry entry) {
        if (!plugin.money().ready()) {
            player.sendMessage(Component.text("The shop can't reach the economy. Tell an admin (needs Vault + an economy plugin).",
                    NamedTextColor.RED));
            return;
        }
        if (!plugin.money().has(player, entry.price())) {
            player.sendMessage(Component.text("You need " + Money.format(entry.price()) + " to buy that.", NamedTextColor.RED));
            return;
        }
        if (!plugin.money().withdraw(player, entry.price())) {
            player.sendMessage(Component.text("The payment failed.", NamedTextColor.RED));
            return;
        }

        boolean allRan = true;
        for (String command : entry.commands()) {
            String run = command.replace("%player%", player.getName());
            if (!Bukkit.dispatchCommand(Bukkit.getConsoleSender(), run)) {
                allRan = false;
            }
        }
        if (!allRan) {
            plugin.money().deposit(player, entry.price());
            player.sendMessage(Component.text("Couldn't give the spawner, so you were refunded. Tell an admin.",
                    NamedTextColor.RED));
            return;
        }

        player.sendMessage(Component.text("You bought a " + plainName(entry) + " for "
                + Money.format(entry.price()) + ".", NamedTextColor.GREEN));
    }

    private static String plainName(Entry entry) {
        String[] words = entry.id().toLowerCase().split("_");
        StringBuilder builder = new StringBuilder();
        for (String word : words) {
            if (word.isEmpty()) {
                continue;
            }
            builder.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1)).append(' ');
        }
        return builder.append("Spawner").toString();
    }
}
