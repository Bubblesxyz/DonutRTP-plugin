package dev.servershop;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionType;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ShopPlugin extends JavaPlugin implements Listener, CommandExecutor {
    private final List<Category> categories = new ArrayList<>();
    private final Money money = new Money();
    private ShopMenu menu;

    @Override
    public void onEnable() {
        File file = new File(getDataFolder(), "shop.yml");
        if (!file.exists()) {
            saveResource("shop.yml", false);
        }
        loadShop(file);

        menu = new ShopMenu(this);
        getServer().getPluginManager().registerEvents(this, this);

        PluginCommand command = getCommand("shop");
        if (command != null) {
            command.setExecutor(this);
        }
    }

    List<Category> categories() {
        return categories;
    }

    Money money() {
        return money;
    }

    private void loadShop(File file) {
        categories.clear();
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = config.getConfigurationSection("categories");
        if (root == null) {
            getLogger().warning("shop.yml has no 'categories' section.");
            return;
        }

        for (String id : root.getKeys(false)) {
            ConfigurationSection section = root.getConfigurationSection(id);
            if (section == null) {
                continue;
            }
            Material icon = Material.matchMaterial(section.getString("icon", "STONE"));
            if (icon == null) {
                getLogger().warning("Category " + id + ": unknown icon, skipped.");
                continue;
            }

            List<ShopItem> items = new ArrayList<>();
            ConfigurationSection itemSection = section.getConfigurationSection("items");
            if (itemSection != null) {
                for (String key : itemSection.getKeys(false)) {
                    Material material;
                    PotionType potion = null;
                    if (key.startsWith("TIPPED_ARROW_")) {
                        material = Material.TIPPED_ARROW;
                        String effect = key.substring("TIPPED_ARROW_".length()).toLowerCase(Locale.ROOT);
                        potion = Registry.POTION.get(NamespacedKey.minecraft(effect));
                        if (potion == null) {
                            getLogger().warning("Category " + id + ": unknown potion in '" + key + "', skipped.");
                            continue;
                        }
                    } else {
                        material = Material.matchMaterial(key);
                    }
                    double price = itemSection.getDouble(key);
                    if (material == null || !material.isItem() || material.isAir()) {
                        getLogger().warning("Category " + id + ": '" + key + "' is not a valid item, skipped.");
                        continue;
                    }
                    if (price <= 0) {
                        getLogger().warning("Category " + id + ": '" + key + "' has no valid price, skipped.");
                        continue;
                    }
                    items.add(new ShopItem(material, potion, price));
                }
            }

            categories.add(new Category(
                    id,
                    section.getString("name", id.toUpperCase(Locale.ROOT)),
                    section.getString("view", id),
                    section.getString("title", id.toUpperCase(Locale.ROOT)),
                    icon,
                    Math.max(1, Math.min(28, section.getInt("per-page", 28))),
                    items));
        }
        getLogger().info("Loaded " + categories.size() + " shop categories.");
    }

    // ---- /shop, /media/shop, /media shop ----

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use the shop.");
            return true;
        }
        menu.openMain(player);
        return true;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommandPreprocess(PlayerCommandPreprocessEvent event) {
        String message = event.getMessage().trim().toLowerCase(Locale.ROOT);
        if (message.equals("/media shop") || message.equals("/media/shop")) {
            event.setCancelled(true);
            menu.openMain(event.getPlayer());
        }
    }

    // ---- keep the menus read-only ----

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof ShopHolder holder)) {
            return;
        }
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player) || event.getClickedInventory() != top) {
            return;
        }
        int slot = event.getSlot();
        getServer().getScheduler().runTask(this, () -> menu.handleClick(player, holder, slot));
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof ShopHolder) {
            event.setCancelled(true);
        }
    }
}
