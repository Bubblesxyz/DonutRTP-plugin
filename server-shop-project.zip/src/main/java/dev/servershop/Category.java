package dev.servershop;

import org.bukkit.Material;

import java.util.List;

record Category(String id, String name, String view, String title, Material icon,
                int menuSlot, int rows, List<Integer> slots, List<ShopItem> items) {
}
