package dev.servershop;

import org.bukkit.Material;

import java.util.List;

record Category(String id, String name, String view, String title, Material icon,
                int perPage, List<ShopItem> items) {
}
