package dev.servershop;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

import java.util.Locale;

/** One thing for sale. price = price of ONE item. potion = effect for tipped arrows (else null). */
record ShopItem(Material material, PotionType potion, double price) {

    ItemStack create(int amount) {
        ItemStack stack = new ItemStack(material, amount);
        if (potion != null && stack.getItemMeta() instanceof PotionMeta meta) {
            meta.setBasePotionType(potion);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    String displayName() {
        if (potion != null) {
            String effect = words(potion.getKey().getKey());
            return material == Material.TIPPED_ARROW ? "Arrow Of " + effect : words(material.name()) + " Of " + effect;
        }
        return words(material.name());
    }

    private static String words(String raw) {
        StringBuilder builder = new StringBuilder();
        for (String part : raw.toLowerCase(Locale.ROOT).split("_")) {
            if (part.isEmpty()) {
                continue;
            }
            if (builder.length() > 0) {
                builder.append(' ');
            }
            builder.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return builder.toString();
    }
}
