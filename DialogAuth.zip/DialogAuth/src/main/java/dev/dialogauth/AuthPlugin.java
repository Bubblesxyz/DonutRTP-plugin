package dev.dialogauth;

import io.papermc.paper.connection.PlayerConfigurationConnection;
import io.papermc.paper.dialog.DialogResponseView;
import io.papermc.paper.event.connection.PlayerConnectionCloseEvent;
import io.papermc.paper.event.connection.configuration.AsyncPlayerConnectionConfigureEvent;
import io.papermc.paper.event.player.PlayerCustomClickEvent;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * Players log in or register in the configuration phase, which is the stage before
 * they are placed in the world. Until they finish, no player entity exists for them:
 * they are not in the world, and no one can see their coordinates or anything else.
 */
public final class AuthPlugin extends JavaPlugin implements Listener {

    private enum Result { SUBMIT, LOGOUT, TIMEOUT, CLOSED }

    private record Submission(Result result, String password, String confirm) {
        static Submission of(Result r) { return new Submission(r, "", ""); }
    }

    private AccountStore store;
    private final Set<UUID> authenticated = ConcurrentHashMap.newKeySet();
    private final ConcurrentHashMap<UUID, CompletableFuture<Submission>> pending = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        store = new AccountStore(getDataFolder());
        getServer().getPluginManager().registerEvents(this, this);
    }

    @EventHandler
    void onConfigure(AsyncPlayerConnectionConfigureEvent event) {
        PlayerConfigurationConnection conn = event.getConnection();
        UUID id = conn.getProfile().getId();
        String name = conn.getProfile().getName();
        if (id == null || name == null) {
            conn.disconnect(Component.text("Could not read your profile.", NamedTextColor.RED));
            return;
        }
        // This event can run again if a player is sent back to configuration. Already logged in? Skip.
        if (authenticated.contains(id)) return;

        // Someone else is already on the login screen with this name.
        if (pending.containsKey(id)) {
            conn.disconnect(Component.text("This name is already logging in.", NamedTextColor.RED));
            return;
        }

        Audience audience = conn.getAudience();
        boolean registered = store.isRegistered(name);
        int maxAttempts = getConfig().getInt("max-attempts", 5);
        int timeout = getConfig().getInt("timeout-seconds", 120);
        int minLength = getConfig().getInt("min-password-length", 6);
        Component error = null;

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            CompletableFuture<Submission> future = new CompletableFuture<>();
            future.completeOnTimeout(Submission.of(Result.TIMEOUT), timeout, TimeUnit.SECONDS);
            pending.put(id, future);

            audience.showDialog(registered ? AuthDialogs.login(name, error) : AuthDialogs.register(name, error));

            // Blocking here is what holds the player in the configuration phase.
            Submission s = future.join();
            pending.remove(id);

            switch (s.result()) {
                case CLOSED -> { return; } // they left
                case LOGOUT -> {
                    audience.closeDialog();
                    conn.disconnect(Component.text("You logged out.", NamedTextColor.YELLOW));
                    return;
                }
                case TIMEOUT -> {
                    audience.closeDialog();
                    conn.disconnect(Component.text("Login timed out.", NamedTextColor.RED));
                    return;
                }
                case SUBMIT -> { }
            }

            if (registered) {
                if (store.verify(name, s.password())) {
                    authenticated.add(id);
                    audience.closeDialog();
                    return;
                }
                error = Component.text("Wrong password. Attempts left: " + (maxAttempts - attempt),
                        NamedTextColor.RED);
            } else {
                if (s.password().length() < minLength) {
                    error = Component.text("Password must be at least " + minLength + " characters.",
                            NamedTextColor.RED);
                } else if (!s.password().equals(s.confirm())) {
                    error = Component.text("The passwords do not match.", NamedTextColor.RED);
                } else {
                    try {
                        store.register(name, s.password());
                    } catch (IOException e) {
                        getLogger().severe("Could not save account for " + name + ": " + e.getMessage());
                        conn.disconnect(Component.text("Server error, try again later.", NamedTextColor.RED));
                        return;
                    }
                    authenticated.add(id);
                    audience.closeDialog();
                    return;
                }
                attempt--; // typos while registering should not count as failed logins
            }
        }

        audience.closeDialog();
        conn.disconnect(Component.text("Too many failed attempts.", NamedTextColor.RED));
    }

    @EventHandler
    void onClick(PlayerCustomClickEvent event) {
        if (!(event.getCommonConnection() instanceof PlayerConfigurationConnection conn)) return;

        Key key = event.getIdentifier();
        if (!key.equals(AuthDialogs.SUBMIT) && !key.equals(AuthDialogs.LOGOUT)) return;

        UUID id = conn.getProfile().getId();
        CompletableFuture<Submission> future = id == null ? null : pending.get(id);
        if (future == null) return;

        if (key.equals(AuthDialogs.LOGOUT)) {
            future.complete(Submission.of(Result.LOGOUT));
            return;
        }

        DialogResponseView view = event.getDialogResponseView();
        String password = view == null ? "" : nullToEmpty(view.getText("password"));
        String confirm = view == null ? "" : nullToEmpty(view.getText("confirm"));
        future.complete(new Submission(Result.SUBMIT, password, confirm));
    }

    @EventHandler
    void onClose(PlayerConnectionCloseEvent event) {
        UUID id = event.getPlayerUniqueId();
        CompletableFuture<Submission> future = pending.remove(id);
        if (future != null) future.complete(Submission.of(Result.CLOSED));
        authenticated.remove(id);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("authreset")) return false;
        if (args.length != 1) {
            sender.sendMessage(Component.text("Usage: /authreset <player>", NamedTextColor.RED));
            return true;
        }
        try {
            boolean removed = store.remove(args[0]);
            sender.sendMessage(removed
                    ? Component.text(args[0] + " can now register a new password.", NamedTextColor.GREEN)
                    : Component.text("No account found for " + args[0] + ".", NamedTextColor.RED));
        } catch (IOException e) {
            sender.sendMessage(Component.text("Could not save: " + e.getMessage(), NamedTextColor.RED));
        }
        return true;
    }

    private static String nullToEmpty(String s) { return s == null ? "" : s; }
}
