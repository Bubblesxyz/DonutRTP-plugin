package dev.dialogauth;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

import java.util.ArrayList;
import java.util.List;

/** Builds the register and login menus. */
final class AuthDialogs {

    static final Key SUBMIT = Key.key("dialogauth", "submit");
    static final Key LOGOUT = Key.key("dialogauth", "logout");

    private AuthDialogs() {}

    static Dialog register(String name, Component error) {
        List<DialogBody> body = new ArrayList<>();
        body.add(DialogBody.plainMessage(welcome(name)));
        body.add(DialogBody.plainMessage(Component.text("You must ", NamedTextColor.YELLOW)
                .append(Component.text("create a password", NamedTextColor.AQUA))
                .append(Component.text(" to log in to the server.", NamedTextColor.YELLOW))));
        body.add(DialogBody.plainMessage(
                Component.text("Please fill in the fields below to continue.", NamedTextColor.YELLOW)));
        if (error != null) body.add(DialogBody.plainMessage(error));

        List<DialogInput> inputs = List.of(
                DialogInput.text("password", Component.text("Password")).width(300).build(),
                DialogInput.text("confirm", Component.text("Confirmation")).width(300).build());

        return build(Component.text("Creating a Password", NamedTextColor.YELLOW),
                body, inputs, "Create Account");
    }

    static Dialog login(String name, Component error) {
        List<DialogBody> body = new ArrayList<>();
        body.add(DialogBody.plainMessage(welcome(name)));
        body.add(DialogBody.plainMessage(
                Component.text("Please enter your password to log in to the server.", NamedTextColor.YELLOW)));
        if (error != null) body.add(DialogBody.plainMessage(error));

        List<DialogInput> inputs = List.of(
                DialogInput.text("password", Component.text("Password")).width(300).build());

        return build(Component.text("Enter your Password", NamedTextColor.YELLOW),
                body, inputs, "Log In");
    }

    private static Component welcome(String name) {
        return Component.text("Welcome, ", NamedTextColor.GOLD)
                .append(Component.text(name, NamedTextColor.WHITE))
                .append(Component.text("!", NamedTextColor.GOLD));
    }

    private static Dialog build(Component title, List<DialogBody> body, List<DialogInput> inputs, String submitLabel) {
        ActionButton submit = ActionButton.create(
                Component.text(submitLabel), null, 200,
                DialogAction.customClick(SUBMIT, null));
        ActionButton logout = ActionButton.create(
                Component.text("Logout"), null, 200,
                DialogAction.customClick(LOGOUT, null));

        return Dialog.create(builder -> builder.empty()
                .base(DialogBase.builder(title)
                        .canCloseWithEscape(false)
                        .afterAction(DialogBase.DialogAfterAction.WAIT_FOR_RESPONSE)
                        .body(body)
                        .inputs(inputs)
                        .build())
                .type(DialogType.multiAction(List.of(submit), logout, 1)));
    }
}
