package dev.dialogauth;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Locale;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Stores accounts in accounts.yml. Passwords are salted PBKDF2 hashes, never plain text. */
final class AccountStore {

    private static final int ITERATIONS = 120_000;
    private static final int KEY_BITS = 256;

    private final File file;
    private final YamlConfiguration yaml;
    private final SecureRandom random = new SecureRandom();

    AccountStore(File dataFolder) {
        dataFolder.mkdirs();
        this.file = new File(dataFolder, "accounts.yml");
        this.yaml = YamlConfiguration.loadConfiguration(file);
    }

    private static String key(String name) {
        return "accounts." + name.toLowerCase(Locale.ROOT);
    }

    synchronized boolean isRegistered(String name) {
        return yaml.isString(key(name));
    }

    synchronized void register(String name, String password) throws IOException {
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        byte[] hash = hash(password, salt, ITERATIONS);
        yaml.set(key(name), ITERATIONS + "$"
                + Base64.getEncoder().encodeToString(salt) + "$"
                + Base64.getEncoder().encodeToString(hash));
        yaml.save(file);
    }

    synchronized boolean verify(String name, String password) {
        String stored = yaml.getString(key(name));
        if (stored == null) return false;
        String[] parts = stored.split("\\$");
        if (parts.length != 3) return false;
        byte[] salt = Base64.getDecoder().decode(parts[1]);
        byte[] expected = Base64.getDecoder().decode(parts[2]);
        byte[] actual = hash(password, salt, Integer.parseInt(parts[0]));
        return MessageDigest.isEqual(expected, actual);
    }

    synchronized boolean remove(String name) throws IOException {
        if (!isRegistered(name)) return false;
        yaml.set(key(name), null);
        yaml.save(file);
        return true;
    }

    private static byte[] hash(String password, byte[] salt, int iterations) {
        try {
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, iterations, KEY_BITS);
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }
}
