package dev.stackfix;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BannerMeta;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.inventory.meta.MapMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Vanilla only stacks two items when every hidden tag matches. If some plugin adds a tag to items,
 * plain items stop stacking. This plugin does the merging itself when a player picks something up,
 * comparing only the item type, so the hidden tags no longer matter. It doesn't touch any other plugin.
 */
public final class StackFixPlugin extends JavaPlugin implements Listener, CommandExecutor {

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        PluginCommand command = getCommand("stackfix");
        if (command != null) {
            command.setExecutor(this);
        }
    }

    // ------------------------------------------------------------------ the fix

    /**
     * Treats ordinary items of the same material as the same item, whatever hidden tags they carry.
     * The dropped item is merged into existing stacks first, then into empty slots. Anything that
     * doesn't fit stays on the ground. Special items (named, enchanted, potions, spawners...) are
     * left to vanilla.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        Item drop = event.getItem();
        ItemStack dropped = drop.getItemStack();
        if (!isPlain(dropped)) {
            return;
        }

        int max = dropped.getMaxStackSize();
        int before = dropped.getAmount();
        int remaining = before;

        ItemStack[] contents = player.getInventory().getStorageContents();

        // 1) top up stacks of the same material
        for (int slot = 0; slot < contents.length && remaining > 0; slot++) {
            ItemStack held = contents[slot];
            if (held == null || held.getType() != dropped.getType() || held.getAmount() >= max || !isPlain(held)) {
                continue;
            }
            int add = Math.min(max - held.getAmount(), remaining);
            held.setAmount(held.getAmount() + add);
            remaining -= add;
        }

        // 2) empty slots
        for (int slot = 0; slot < contents.length && remaining > 0; slot++) {
            if (contents[slot] == null || contents[slot].getType().isAir()) {
                ItemStack placed = dropped.clone();
                int put = Math.min(max, remaining);
                placed.setAmount(put);
                contents[slot] = placed;
                remaining -= put;
            }
        }

        if (remaining == before) {
            return; // nothing fits - let vanilla decide
        }

        event.setCancelled(true);
        player.getInventory().setStorageContents(contents);
        player.playPickupItemAnimation(drop, before - remaining);

        if (remaining <= 0) {
            drop.remove();
        } else {
            ItemStack rest = dropped.clone();
            rest.setAmount(remaining);
            drop.setItemStack(rest);
        }
    }

    /** Only ordinary stackable items: no name, lore, enchants, special data. Never spawners. */
    @SuppressWarnings("deprecation")
    private static boolean isPlain(ItemStack stack) {
        if (stack == null || stack.getType().isAir() || stack.getType() == Material.SPAWNER
                || stack.getMaxStackSize() < 2) {
            return false;
        }
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return false;
        }
        if (meta.hasDisplayName() || meta.hasItemName() || meta.hasLore() || meta.hasEnchants()
                || meta.hasAttributeModifiers() || meta.hasCustomModelData()) {
            return false;
        }
        return !(meta instanceof PotionMeta || meta instanceof BookMeta || meta instanceof EnchantmentStorageMeta
                || meta instanceof BlockStateMeta || meta instanceof FireworkMeta || meta instanceof BannerMeta
                || meta instanceof MapMeta || meta instanceof SkullMeta || meta instanceof LeatherArmorMeta);
    }

    // --------------------------------------------------------- /stackfix check

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("stackfix.admin")) {
            sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
            return true;
        }
        if (!(sender instanceof Player player) || args.length == 0 || !args[0].equalsIgnoreCase("check")) {
            sender.sendMessage(Component.text("Hold an item, stand next to a dropped one of the same kind, then run /stackfix check",
                    NamedTextColor.YELLOW));
            return true;
        }

        ItemStack held = player.getInventory().getItemInMainHand();
        Item nearest = null;
        double best = Double.MAX_VALUE;
        for (Entity entity : player.getNearbyEntities(6, 6, 6)) {
            if (entity instanceof Item item) {
                double distance = item.getLocation().distanceSquared(player.getLocation());
                if (distance < best) {
                    best = distance;
                    nearest = item;
                }
            }
        }

        player.sendMessage(Component.text("Held:    " + describe(held), NamedTextColor.AQUA));
        if (nearest == null) {
            player.sendMessage(Component.text("No dropped item within 6 blocks.", NamedTextColor.RED));
            return true;
        }
        ItemStack dropped = nearest.getItemStack();
        player.sendMessage(Component.text("Dropped: " + describe(dropped), NamedTextColor.GREEN));
        player.sendMessage(Component.text(held.isSimilar(dropped)
                ? "These two WOULD stack."
                : "These two will NOT stack - the difference is above.", NamedTextColor.YELLOW));
        return true;
    }

    private static String describe(ItemStack stack) {
        if (stack == null || stack.getType().isAir()) {
            return "(nothing)";
        }
        ItemMeta meta = stack.getItemMeta();
        String components = meta == null ? "" : meta.getAsComponentString();
        return stack.getType().getKey().getKey() + " " + (components == null || components.isEmpty() ? "[no extra data]" : components)
                + " (max stack " + stack.getMaxStackSize() + ")";
    }
}
