package dev.settingsmenu;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickCallback;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** The dialog screens: main menu, one screen per category. */
final class SettingsMenu {
    private static final int WIDTH = 300;

    private SettingsMenu() {
    }

    static void openMain(SettingsPlugin plugin, Player player) {
        List<ActionButton> buttons = new ArrayList<>();
        for (Settings.Category category : Settings.CATEGORIES) {
            buttons.add(button(Component.text(category.name()),
                    click(plugin, p -> openCategory(plugin, p, category))));
        }
        ActionButton close = button(Component.text("Close"), null);
        show(player, Component.text("Settings"), buttons, close);
    }

    static void openCategory(SettingsPlugin plugin, Player player, Settings.Category category) {
        List<ActionButton> buttons = new ArrayList<>();

        for (Settings.Setting setting : category.settings()) {
            boolean locked = plugin.isLocked(player, setting);

            Component state;
            if (locked) {
                state = Component.text("LOCKED", NamedTextColor.RED);
            } else if (plugin.isOn(player, setting)) {
                state = Component.text("ON", NamedTextColor.GREEN);
            } else {
                state = Component.text("OFF", NamedTextColor.RED);
            }
            Component label = Component.text(setting.name() + ": ").append(state);

            if (locked) {
                buttons.add(button(label, click(plugin, p -> {
                    p.sendMessage(Component.text("That setting is locked.", NamedTextColor.RED));
                    openCategory(plugin, p, category);
                })));
            } else {
                buttons.add(button(label, click(plugin, p -> {
                    plugin.toggle(p, setting);
                    openCategory(plugin, p, category);
                })));
            }
        }

        ActionButton back = button(Component.text("Back"), click(plugin, p -> openMain(plugin, p)));
        show(player, Component.text("Settings - " + category.name(), NamedTextColor.AQUA), buttons, back);
    }

    private static ActionButton button(Component label, DialogAction action) {
        ActionButton.Builder builder = ActionButton.builder(label).width(WIDTH);
        if (action != null) {
            builder.action(action);
        }
        return builder.build();
    }

    private static DialogAction click(SettingsPlugin plugin, Consumer<Player> run) {
        return DialogAction.customClick((view, audience) -> {
            if (audience instanceof Player player) {
                Bukkit.getScheduler().runTask(plugin, () -> run.accept(player));
            }
        }, ClickCallback.Options.builder().uses(ClickCallback.UNLIMITED_USES).build());
    }

    private static void show(Player player, Component title, List<ActionButton> buttons, ActionButton exit) {
        Dialog dialog = Dialog.create(factory -> factory.empty()
                .base(DialogBase.builder(title).canCloseWithEscape(true).build())
                .type(DialogType.multiAction(buttons, exit, 1)));
        player.showDialog(dialog);
    }
}
