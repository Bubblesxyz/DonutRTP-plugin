package dev.settingsmenu;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Phantom;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Locale;
import java.util.Set;

public final class SettingsPlugin extends JavaPlugin implements Listener, CommandExecutor {
    private static final Set<String> MESSAGE_COMMANDS = Set.of("msg", "tell", "w", "whisper", "m", "t", "pm", "dm");

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        PluginCommand command = getCommand("settings");
        if (command != null) {
            command.setExecutor(this);
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Only players can use this command."));
            return true;
        }
        SettingsMenu.openMain(this, player);
        return true;
    }

    // ---- reading / changing settings ----

    private NamespacedKey key(Settings.Setting setting) {
        return new NamespacedKey(this, setting.id());
    }

    boolean isOn(Player player, Settings.Setting setting) {
        if (setting.mutePermission() != null) {
            // permission-backed: having the mute permission means OFF
            return !player.hasPermission(setting.mutePermission());
        }
        Byte value = player.getPersistentDataContainer().get(key(setting), PersistentDataType.BYTE);
        if (value == null) {
            return setting.def();
        }
        return value != 0;
    }

    /** For other plugins/code: isOn(player, "pay_alerts"). */
    public boolean isOn(Player player, String id) {
        Settings.Setting setting = Settings.byId(id);
        return setting != null && isOn(player, setting);
    }

    boolean isLocked(Player player, Settings.Setting setting) {
        return setting.lockPermission() != null && !player.hasPermission(setting.lockPermission());
    }

    void toggle(Player player, Settings.Setting setting) {
        boolean turnOn = !isOn(player, setting);

        if (setting.mutePermission() != null) {
            // mute permission true = OFF, false = ON
            runPermissionCommand(player, setting.mutePermission(), !turnOn);
            return;
        }

        player.getPersistentDataContainer().set(key(setting), PersistentDataType.BYTE, (byte) (turnOn ? 1 : 0));
        applyEffects(player);
    }

    private void runPermissionCommand(Player player, String permission, boolean value) {
        String template = value
                ? getConfig().getString("permission-commands.grant", "lp user %player% permission set %permission% true")
                : getConfig().getString("permission-commands.revoke", "lp user %player% permission set %permission% false");
        String command = template.replace("%player%", player.getName()).replace("%permission%", permission);
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
    }

    // ---- settings that do something ----

    void applyEffects(Player player) {
        Settings.Setting nightVision = Settings.byId("night_vision");
        if (isOn(player, nightVision)) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION,
                    PotionEffect.INFINITE_DURATION, 0, false, false, false));
        } else {
            PotionEffect current = player.getPotionEffect(PotionEffectType.NIGHT_VISION);
            if (current != null && current.getDuration() == PotionEffect.INFINITE_DURATION) {
                player.removePotionEffect(PotionEffectType.NIGHT_VISION);
            }
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        applyEffects(event.getPlayer());
    }

    /** Public Chat OFF: that player stops seeing other people's chat messages. */
    @EventHandler
    public void onChat(AsyncChatEvent event) {
        Settings.Setting publicChat = Settings.byId("public_chat");
        Player sender = event.getPlayer();
        event.viewers().removeIf(audience ->
                audience instanceof Player viewer && !viewer.equals(sender) && !isOn(viewer, publicChat));
    }

    /** Private Messages OFF: /msg, /tell, /w ... to that player is blocked. */
    @EventHandler(ignoreCancelled = true)
    public void onCommandPreprocess(PlayerCommandPreprocessEvent event) {
        String[] parts = event.getMessage().trim().split("\\s+");
        if (parts.length < 2) {
            return;
        }
        String name = parts[0].substring(1).toLowerCase(Locale.ROOT);
        int colon = name.indexOf(':');
        if (colon >= 0) {
            name = name.substring(colon + 1);
        }
        if (!MESSAGE_COMMANDS.contains(name)) {
            return;
        }
        Player target = Bukkit.getPlayerExact(parts[1]);
        if (target == null) {
            return;
        }
        if (isOn(target, Settings.byId("private_messages")) || event.getPlayer().hasPermission("settingsmenu.bypass")) {
            return;
        }
        event.setCancelled(true);
        event.getPlayer().sendMessage(Component.text(target.getName() + " has private messages turned off.",
                NamedTextColor.RED));
    }

    /** Kill Messages / Death Messages: only players with it ON see them. Destroy Pearl on Death. */
    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();

        Settings.Setting pearl = Settings.byId("destroy_pearl");
        if (!isLocked(victim, pearl) && isOn(victim, pearl)) {
            for (EnderPearl thrown : victim.getWorld().getEntitiesByClass(EnderPearl.class)) {
                if (thrown.getShooter() instanceof Player shooter
                        && shooter.getUniqueId().equals(victim.getUniqueId())) {
                    thrown.remove();
                }
            }
        }

        Component message = event.deathMessage();
        if (message == null) {
            return;
        }
        event.deathMessage(null);

        Settings.Setting setting = Settings.byId(victim.getKiller() != null ? "kill_messages" : "death_messages");
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (isOn(online, setting)) {
                online.sendMessage(message);
            }
        }
        Bukkit.getConsoleSender().sendMessage(message);
    }

    /** Mob Spawns / Phantom Spawning OFF: natural spawns are blocked near that player. */
    @EventHandler
    public void onSpawn(CreatureSpawnEvent event) {
        if (event.getSpawnReason() != CreatureSpawnEvent.SpawnReason.NATURAL) {
            return;
        }
        Entity entity = event.getEntity();
        if (!(entity instanceof Monster)) {
            return;
        }
        Settings.Setting mobs = Settings.byId("mob_spawns");
        Settings.Setting phantoms = Settings.byId("phantom_spawning");
        boolean isPhantom = entity instanceof Phantom;

        for (Player player : entity.getWorld().getNearbyPlayers(entity.getLocation(), 64)) {
            if (!isOn(player, mobs) || (isPhantom && !isOn(player, phantoms))) {
                event.setCancelled(true);
                return;
            }
        }
    }
}
