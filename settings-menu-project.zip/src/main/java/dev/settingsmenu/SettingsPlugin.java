package dev.settingsmenu;

import net.kyori.adventure.text.Component;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Phantom;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class SettingsPlugin extends JavaPlugin implements Listener, CommandExecutor {

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        PluginCommand command = getCommand("settings");
        if (command != null) {
            command.setExecutor(this);
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Only players can use this command."));
            return true;
        }
        SettingsMenu.openMain(this, player);
        return true;
    }

    // ---- storing settings (saved on the player, survives restarts) ----

    private NamespacedKey key(Settings.Setting setting) {
        return new NamespacedKey(this, setting.id());
    }

    boolean isOn(Player player, Settings.Setting setting) {
        Byte value = player.getPersistentDataContainer().get(key(setting), PersistentDataType.BYTE);
        if (value == null) {
            return setting.def();
        }
        return value != 0;
    }

    /** For other plugins/code: SettingsPlugin.isOn(player, "pay_alerts"). */
    public boolean isOn(Player player, String id) {
        Settings.Setting setting = Settings.byId(id);
        return setting != null && isOn(player, setting);
    }

    boolean isLocked(Player player, Settings.Setting setting) {
        return setting.lockPermission() != null && !player.hasPermission(setting.lockPermission());
    }

    void toggle(Player player, Settings.Setting setting) {
        boolean next = !isOn(player, setting);
        player.getPersistentDataContainer().set(key(setting), PersistentDataType.BYTE, (byte) (next ? 1 : 0));
        applyEffects(player);
    }

    // ---- settings that actually do something ----

    void applyEffects(Player player) {
        Settings.Setting nightVision = Settings.byId("night_vision");
        if (isOn(player, nightVision)) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION,
                    PotionEffect.INFINITE_DURATION, 0, false, false, false));
        } else {
            PotionEffect current = player.getPotionEffect(PotionEffectType.NIGHT_VISION);
            if (current != null && current.getDuration() == PotionEffect.INFINITE_DURATION) {
                player.removePotionEffect(PotionEffectType.NIGHT_VISION);
            }
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        applyEffects(event.getPlayer());
    }

    /** Natural spawns are blocked near players who turned Mob Spawns / Phantom Spawning off. */
    @EventHandler
    public void onSpawn(CreatureSpawnEvent event) {
        if (event.getSpawnReason() != CreatureSpawnEvent.SpawnReason.NATURAL) {
            return;
        }
        Entity entity = event.getEntity();
        if (!(entity instanceof Monster)) {
            return;
        }
        Settings.Setting mobs = Settings.byId("mob_spawns");
        Settings.Setting phantoms = Settings.byId("phantom_spawning");
        boolean isPhantom = entity instanceof Phantom;

        for (Player player : entity.getWorld().getNearbyPlayers(entity.getLocation(), 64)) {
            if (!isOn(player, mobs) || (isPhantom && !isOn(player, phantoms))) {
                event.setCancelled(true);
                return;
            }
        }
    }
}
