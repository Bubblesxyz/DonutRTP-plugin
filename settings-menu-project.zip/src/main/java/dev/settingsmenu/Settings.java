package dev.settingsmenu;

import java.util.List;

/** All categories and settings. Edit this file to add, remove or rename things. */
final class Settings {
    private Settings() {
    }

    /** id = storage key, def = default value, lockPermission = null if never locked. */
    record Setting(String id, String name, boolean def, String lockPermission, String mutePermission) {
        Setting(String id, String name, boolean def) {
            this(id, name, def, null, null);
        }

        Setting(String id, String name, boolean def, String lockPermission) {
            this(id, name, def, lockPermission, null);
        }

        /** A switch backed by a "mute" permission: having the permission means OFF (LuckPerms flips it). */
        static Setting muteSwitch(String id, String name, String mutePermission) {
            return new Setting(id, name, true, null, mutePermission);
        }
    }

    record Category(String name, List<Setting> settings) {
    }

    static final List<Category> CATEGORIES = List.of(
            new Category("General", List.of(
                    new Setting("quick_buy", "Auction Quick Buy", false, "settingsmenu.unlock.quick_buy"),
                    new Setting("quick_sell", "Auction Quick Sell", false, "settingsmenu.unlock.quick_sell"),
                    new Setting("mob_spawns", "Mob Spawns", true),
                    new Setting("phantom_spawning", "Phantom Spawning", true),
                    new Setting("night_vision", "Night Vision", false),
                    new Setting("destroy_pearl", "Destroy Pearl on Death", false, "settingsmenu.unlock.destroy_pearl"),
                    new Setting("money_name_tag", "Money Name Tag", true))),
            new Category("Chat", List.of(
                    new Setting("public_chat", "Public Chat", true),
                    new Setting("private_messages", "Private Messages", true),
                    new Setting("chat_mentions", "Chat Mentions", true))),
            new Category("Notifications", List.of(
                    new Setting("pay_alerts", "Pay Alerts", true),
                    Setting.muteSwitch("bounty_alerts", "Bounty Alerts", "skbounty.mute"),
                    new Setting("tpa_alerts", "Tpa Alerts", true),
                    Setting.muteSwitch("auction_alerts", "Auction Alerts", "skauction.mute"),
                    new Setting("coinflip_alerts", "Coinflip Alerts", true),
                    new Setting("order_alerts", "Order Alerts", true),
                    new Setting("sound_alerts", "Sound Alerts", false, "settingsmenu.unlock.sound_alerts"))),
            new Category("PvP", List.of(
                    new Setting("kill_messages", "Kill Messages", true),
                    new Setting("death_messages", "Death Messages", true),
                    new Setting("combat_timer", "Combat Timer", true))),
            new Category("Visuals", List.of(
                    new Setting("particles", "Particles", true),
                    new Setting("damage_numbers", "Damage Numbers", true),
                    new Setting("low_fire", "Low Fire", false))),
            new Category("Privacy", List.of(
                    new Setting("accept_tpa", "Accept TPA Requests", true),
                    new Setting("accept_pay", "Accept Payments", true),
                    new Setting("show_last_seen", "Show Last Seen", true))),
            new Category("Scoreboard", List.of(
                    new Setting("show_scoreboard", "Show Scoreboard", true),
                    new Setting("show_money", "Show Money", true),
                    new Setting("show_playtime", "Show Playtime", true))));

    static Setting byId(String id) {
        for (Category category : CATEGORIES) {
            for (Setting setting : category.settings()) {
                if (setting.id().equals(id)) {
                    return setting;
                }
            }
        }
        return null;
    }
}
