package net.skstudios.sellbutton;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Reads prices.yml in the SKSell format:
 *   1. an item listed under categories.<x>.items uses that price (0 or less = cannot be sold)
 *   2. otherwise, if auto-pricing is enabled: never-sell words, then the first matching rule,
 *      then default-price.
 */
final class PriceTable {
    private record Rule(List<String> contains, double price) {}

    private final Map<Material, Double> explicit = new EnumMap<>(Material.class);
    private final Map<Material, Double> cache = new EnumMap<>(Material.class);
    private final List<String> neverSell = new ArrayList<>();
    private final List<Rule> rules = new ArrayList<>();
    private boolean autoEnabled;
    private double defaultPrice;

    static PriceTable load(FileConfiguration yml, Logger log) {
        PriceTable t = new PriceTable();

        ConfigurationSection cats = yml.getConfigurationSection("categories");
        if (cats != null) {
            for (String cat : cats.getKeys(false)) {
                ConfigurationSection items = cats.getConfigurationSection(cat + ".items");
                if (items == null) continue;
                for (String key : items.getKeys(false)) {
                    Material m = Material.matchMaterial(key);
                    if (m == null) {
                        log.warning("prices.yml: unknown material '" + key + "' in category '" + cat + "' - skipped");
                        continue;
                    }
                    t.explicit.put(m, items.getDouble(key));
                }
            }
        }

        ConfigurationSection auto = yml.getConfigurationSection("auto-pricing");
        if (auto != null) {
            t.autoEnabled = auto.getBoolean("enabled", false);
            t.defaultPrice = auto.getDouble("default-price", 1);
            for (String s : auto.getStringList("never-sell")) t.neverSell.add(s.toLowerCase(Locale.ROOT));
            List<Map<?, ?>> raw = auto.getMapList("rules");
            for (Map<?, ?> r : raw) {
                Object c = r.get("contains");
                Object p = r.get("price");
                if (!(c instanceof List<?> words) || !(p instanceof Number num)) continue;
                List<String> w = new ArrayList<>();
                for (Object o : words) w.add(String.valueOf(o).toLowerCase(Locale.ROOT));
                t.rules.add(new Rule(w, num.doubleValue()));
            }
        }
        return t;
    }

    /** Price of ONE item, or 0 if it cannot be sold. */
    double price(Material m) {
        Double hit = cache.get(m);
        if (hit != null) return hit;
        double p = compute(m);
        cache.put(m, p);
        return p;
    }

    private double compute(Material m) {
        if (m.isLegacy() || m.isAir() || !m.isItem()) return 0;
        Double e = explicit.get(m);
        if (e != null) return Math.max(0, e);
        if (!autoEnabled) return 0;
        String name = m.name().toLowerCase(Locale.ROOT).replace('_', ' ');
        for (String s : neverSell) if (name.contains(s)) return 0;
        for (Rule r : rules) {
            for (String c : r.contains()) if (name.contains(c)) return Math.max(0, r.price());
        }
        return Math.max(0, defaultPrice);
    }
}
