package net.skstudios.sellbutton;

import org.bukkit.ChatColor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Colour codes: '&' codes and '&#RRGGBB' hex. */
final class Text {
    private static final Pattern HEX = Pattern.compile("&#([A-Fa-f0-9]{6})");

    private Text() {}

    static String color(String s) {
        if (s == null) return "";
        Matcher m = HEX.matcher(s);
        StringBuilder out = new StringBuilder();
        while (m.find()) {
            StringBuilder hex = new StringBuilder("\u00a7x");
            for (char c : m.group(1).toCharArray()) hex.append('\u00a7').append(c);
            m.appendReplacement(out, Matcher.quoteReplacement(hex.toString()));
        }
        m.appendTail(out);
        return ChatColor.translateAlternateColorCodes('&', out.toString());
    }
}
