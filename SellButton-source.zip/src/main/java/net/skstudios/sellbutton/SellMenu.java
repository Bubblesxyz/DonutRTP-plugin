package net.skstudios.sellbutton;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.ShulkerBox;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The 6-row sell menu.
 *   slot 0       info icon (protected)
 *   slots 1..52  sell slots
 *   slot 53      the green sell button (protected)
 */
final class SellMenu implements InventoryHolder {
    static final int INFO_SLOT = 0;
    static final int BUTTON_SLOT = 53;
    static final int FIRST = 1;
    static final int LAST = 52;

    private record Change(int slot, ItemStack replacement) {} // replacement null = slot becomes empty

    private static final class Appraisal {
        double total;
        long items;
        final List<Change> changes = new ArrayList<>();
    }

    private final SellButtonPlugin plugin;
    private final Player player;
    private final Inventory inv;

    SellMenu(SellButtonPlugin plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
        this.inv = Bukkit.createInventory(this, 54, Text.color(plugin.settings().title));
        inv.setItem(INFO_SLOT, plugin.settings().item("menu.info", "0"));
        refreshButton();
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }

    void open() {
        player.openInventory(inv);
        plugin.settings().play(player, "open");
    }

    static boolean isProtected(int rawSlot) {
        return rawSlot == INFO_SLOT || rawSlot == BUTTON_SLOT;
    }

    /** Puts an item into the sell slots only. Returns what did not fit, or null. */
    ItemStack insert(ItemStack item) {
        for (int s = FIRST; s <= LAST && item.getAmount() > 0; s++) {
            ItemStack cur = inv.getItem(s);
            if (cur == null || !cur.isSimilar(item)) continue;
            int room = cur.getMaxStackSize() - cur.getAmount();
            if (room <= 0) continue;
            int move = Math.min(room, item.getAmount());
            cur.setAmount(cur.getAmount() + move);
            item.setAmount(item.getAmount() - move);
        }
        for (int s = FIRST; s <= LAST && item.getAmount() > 0; s++) {
            ItemStack cur = inv.getItem(s);
            if (cur != null && !cur.getType().isAir()) continue;
            int move = Math.min(item.getMaxStackSize(), item.getAmount());
            ItemStack placed = item.clone();
            placed.setAmount(move);
            inv.setItem(s, placed);
            item.setAmount(item.getAmount() - move);
        }
        return item.getAmount() > 0 ? item : null;
    }

    /** Gives everything still in the sell slots back to the player. */
    void giveBack() {
        for (int s = FIRST; s <= LAST; s++) {
            ItemStack it = inv.getItem(s);
            if (it == null || it.getType().isAir()) continue;
            inv.setItem(s, null);
            for (ItemStack left : player.getInventory().addItem(it).values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), left);
            }
        }
    }

    // ------------------------------------------------------------------ selling

    /** The green button. The menu stays open. */
    void sell() {
        Settings cfg = plugin.settings();
        Appraisal a = appraise();
        double pay = cfg.roundDown ? Math.floor(a.total) : a.total;
        if (a.items == 0 || pay <= 0) {
            player.sendMessage(cfg.message("nothing"));
            cfg.play(player, "rejected");
            return;
        }
        Economy eco = plugin.economy();
        if (eco == null) {
            player.sendMessage(cfg.message("no-economy"));
            cfg.play(player, "rejected");
            return;
        }
        EconomyResponse r = eco.depositPlayer(player, pay);
        if (!r.transactionSuccess()) {
            player.sendMessage(cfg.message("payment-failed"));
            cfg.play(player, "rejected");
            return;
        }
        // Only now that the money is paid do the items disappear.
        for (Change c : a.changes) inv.setItem(c.slot(), c.replacement());
        player.sendMessage(cfg.message("sold")
                .replace("%items%", String.format(Locale.US, "%,d", a.items))
                .replace("%price%", format(pay)));
        cfg.play(player, "sold");
        refreshButton();
    }

    void refreshButton() {
        Appraisal a = appraise();
        inv.setItem(BUTTON_SLOT, plugin.settings().item("menu.button", format(a.total)));
    }

    private String format(double v) {
        if (plugin.settings().roundDown) return String.format(Locale.US, "%,d", (long) Math.floor(v));
        return String.format(Locale.US, "%,.2f", v);
    }

    /** Works out what the menu is worth without touching it. */
    private Appraisal appraise() {
        Appraisal a = new Appraisal();
        for (int s = FIRST; s <= LAST; s++) {
            ItemStack it = inv.getItem(s);
            if (it == null || it.getType().isAir()) continue;
            if (it.getType().name().endsWith("SHULKER_BOX")) appraiseShulker(s, it, a);
            else {
                double v = value(it);
                if (v > 0) {
                    a.total += v;
                    a.items += it.getAmount();
                    a.changes.add(new Change(s, null));
                }
            }
        }
        return a;
    }

    /**
     * A shulker box is sold together with its contents, each item at its own price.
     * Items inside that have no price are never destroyed: the box is handed back
     * with them still inside (and only the sellable items are paid for). A box that ends up
     * empty is sold as well, at its own price.
     */
    private void appraiseShulker(int slot, ItemStack box, Appraisal a) {
        ItemMeta meta = box.getItemMeta();
        BlockStateMeta bsm = (meta instanceof BlockStateMeta b) ? b : null;
        ShulkerBox state = null;
        if (bsm != null && bsm.getBlockState() instanceof ShulkerBox sb) state = sb;
        if (state == null) return;

        Inventory content = state.getInventory();
        double inside = 0;
        long insideItems = 0;
        boolean sold = false;
        boolean leftover = false;
        for (int i = 0; i < content.getSize(); i++) {
            ItemStack in = content.getItem(i);
            if (in == null || in.getType().isAir()) continue;
            double v = value(in);
            if (v > 0) {
                inside += v;
                insideItems += in.getAmount();
                content.setItem(i, null);
                sold = true;
            } else {
                leftover = true;
            }
        }

        double boxValue = leftover ? 0 : value(box);
        if (!sold && boxValue <= 0) return; // nothing to do, the box stays untouched

        a.total += inside + boxValue;
        a.items += insideItems + (boxValue > 0 ? 1 : 0);
        if (boxValue > 0) {
            a.changes.add(new Change(slot, null));
        } else {
            bsm.setBlockState(state);
            ItemStack back = box.clone();
            back.setItemMeta(bsm);
            a.changes.add(new Change(slot, back));
        }
    }

    /** Value of this whole stack, or 0 if it must not be sold. */
    private double value(ItemStack it) {
        Settings cfg = plugin.settings();
        Material m = it.getType();
        double unit = plugin.prices().price(m);
        if (unit <= 0) return 0;

        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            if (!cfg.allowRenamed && meta.hasDisplayName()) return 0;
            if (!cfg.allowEnchanted && hasEnchants(meta)) return 0;
            if (cfg.refusePluginItems && hasForeignData(meta)) return 0;
            if (meta instanceof Damageable d && m.getMaxDurability() > 0 && d.getDamage() > 0) {
                if (cfg.refuseDamaged) return 0;
                if (cfg.scaleDamaged) {
                    double left = (m.getMaxDurability() - d.getDamage()) / (double) m.getMaxDurability();
                    unit *= Math.max(0, left);
                }
            }
        }
        return unit * it.getAmount();
    }

    private static boolean hasEnchants(ItemMeta meta) {
        if (meta.hasEnchants()) return true;
        return meta instanceof EnchantmentStorageMeta es && es.hasStoredEnchants();
    }

    private static boolean hasForeignData(ItemMeta meta) {
        for (NamespacedKey k : meta.getPersistentDataContainer().getKeys()) {
            if (!k.getNamespace().equals("sksell")) return true;
        }
        return false;
    }
}
