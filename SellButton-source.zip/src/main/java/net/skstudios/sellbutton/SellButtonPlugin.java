package net.skstudios.sellbutton;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

public final class SellButtonPlugin extends JavaPlugin implements Listener {
    private Settings settings;
    private PriceTable prices;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveResource("prices.yml", false); // does nothing if it already exists
        loadAll();
        getServer().getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {
        // closing returns whatever players still have in the sell slots
        for (Player p : new ArrayList<>(Bukkit.getOnlinePlayers())) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof SellMenu) p.closeInventory();
        }
    }

    private void loadAll() {
        reloadConfig();
        settings = new Settings(getConfig());
        java.io.File f = new java.io.File(getDataFolder(), "prices.yml");
        prices = PriceTable.load(org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(f), getLogger());
    }

    Settings settings() { return settings; }

    PriceTable prices() { return prices; }

    Economy economy() {
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        return rsp == null ? null : rsp.getProvider();
    }

    // ------------------------------------------------------------------ command

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("sellbutton.admin")) {
                sender.sendMessage(settings.message("no-permission"));
                return true;
            }
            loadAll();
            sender.sendMessage(settings.message("reloaded"));
            return true;
        }
        if (!(sender instanceof Player p)) {
            sender.sendMessage(settings.plainMessage("players-only"));
            return true;
        }
        if (!p.hasPermission("sellbutton.use")) {
            p.sendMessage(settings.message("no-permission"));
            return true;
        }
        new SellMenu(this, p).open();
        return true;
    }

    // ------------------------------------------------------------------ menu events

    private SellMenu menuOf(Inventory top) {
        InventoryHolder h = top.getHolder();
        return h instanceof SellMenu m ? m : null;
    }

    private void refreshLater(SellMenu menu) {
        Bukkit.getScheduler().runTask(this, menu::refreshButton);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        SellMenu menu = menuOf(top);
        if (menu == null) return;

        // a double click gathers matching items from every slot, including the protected ones
        if (e.getClick() == ClickType.DOUBLE_CLICK) {
            e.setCancelled(true);
            return;
        }

        Inventory clicked = e.getClickedInventory();
        if (clicked == null) return;

        if (clicked.equals(top)) {
            int slot = e.getRawSlot();
            if (SellMenu.isProtected(slot)) {
                e.setCancelled(true);
                if (slot == SellMenu.BUTTON_SLOT && (e.isLeftClick() || e.isRightClick())) {
                    menu.sell();
                }
                return;
            }
            refreshLater(menu);
            return;
        }

        // Click in the player's own inventory. Shift-click would drop items into slot 0 / 53,
        // so route it into the sell slots by hand.
        if (e.isShiftClick()) {
            e.setCancelled(true);
            ItemStack cur = e.getCurrentItem();
            if (cur == null || cur.getType().isAir()) return;
            ItemStack rest = menu.insert(cur.clone());
            e.setCurrentItem(rest);
        }
        refreshLater(menu);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        SellMenu menu = menuOf(e.getView().getTopInventory());
        if (menu == null) return;
        for (int raw : e.getRawSlots()) {
            if (SellMenu.isProtected(raw)) {
                e.setCancelled(true);
                return;
            }
        }
        refreshLater(menu);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        SellMenu menu = menuOf(e.getView().getTopInventory());
        if (menu == null) return;
        menu.giveBack();
    }
}
