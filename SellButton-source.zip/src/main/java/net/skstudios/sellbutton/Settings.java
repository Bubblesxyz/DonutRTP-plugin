package net.skstudios.sellbutton;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class Settings {
    final String title;
    final boolean allowRenamed, allowEnchanted, refusePluginItems, refuseDamaged, scaleDamaged, roundDown;

    private final FileConfiguration cfg;

    Settings(FileConfiguration cfg) {
        this.cfg = cfg;
        title = cfg.getString("menu.title", "Sell");
        allowRenamed = cfg.getBoolean("selling.allow-renamed", false);
        allowEnchanted = cfg.getBoolean("selling.allow-enchanted", false);
        refusePluginItems = cfg.getBoolean("selling.refuse-plugin-items", true);
        refuseDamaged = cfg.getBoolean("selling.refuse-damaged", false);
        scaleDamaged = cfg.getBoolean("selling.scale-damaged-price", true);
        roundDown = cfg.getBoolean("selling.round-payout-down", true);
    }

    String message(String key) {
        String prefix = cfg.getString("messages.prefix", "");
        String body = cfg.getString("messages." + key, "");
        return body.isEmpty() ? "" : Text.color(prefix + body);
    }

    String plainMessage(String key) {
        return Text.color(cfg.getString("messages." + key, ""));
    }

    /** Builds the item for menu.info or menu.button; %total% is replaced in name and lore. */
    ItemStack item(String path, String total) {
        ConfigurationSection s = cfg.getConfigurationSection(path);
        Material mat = Material.STONE;
        if (s != null) {
            Material m = Material.matchMaterial(s.getString("material", "STONE"));
            if (m != null && m.isItem()) mat = m;
        }
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        if (meta != null && s != null) {
            meta.setDisplayName(Text.color(s.getString("name", " ").replace("%total%", total)));
            List<String> lore = new ArrayList<>();
            for (String line : s.getStringList("lore")) lore.add(Text.color(line.replace("%total%", total)));
            meta.setLore(lore);
            it.setItemMeta(meta);
        }
        return it;
    }

    void play(Player p, String cue) {
        ConfigurationSection s = cfg.getConfigurationSection("sounds." + cue);
        if (s == null) return;
        String sound = s.getString("sound", "");
        if (sound.isEmpty()) return;
        p.playSound(p.getLocation(), sound.toLowerCase(Locale.ROOT),
                (float) s.getDouble("volume", 1.0), (float) s.getDouble("pitch", 1.0));
    }
}
