package dev.specialitems;

import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Container;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.block.data.Waterlogged;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.util.RayTraceResult;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;

/** The abilities of the special items. */
final class SpecialListener implements Listener {
    private static final int MAX_TREE_LOGS = 256;

    private final SpecialPlugin plugin;
    /** Players whose extra blocks are being broken right now, so we don't react to our own events. */
    private final Set<UUID> busy = new HashSet<>();

    SpecialListener(SpecialPlugin plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------ drill (3x3) and axe (trees)

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (busy.contains(player.getUniqueId())) {
            return;
        }
        ItemStack tool = player.getInventory().getItemInMainHand();
        SpecialType type = plugin.typeOf(tool);
        Block block = event.getBlock();

        if (type == SpecialType.DRILL) {
            BlockFace face = faceOf(player, block);
            for (int a = -1; a <= 1; a++) {
                for (int b = -1; b <= 1; b++) {
                    if (a == 0 && b == 0) {
                        continue;
                    }
                    Block target;
                    if (face.getModX() != 0) {
                        target = block.getRelative(0, a, b);
                    } else if (face.getModY() != 0) {
                        target = block.getRelative(a, 0, b);
                    } else {
                        target = block.getRelative(a, b, 0);
                    }
                    breakExtra(player, target, tool);
                }
            }
        } else if (type == SpecialType.AXE && Tag.LOGS.isTagged(block.getType())) {
            Set<Block> tree = findTree(block);
            if (looksLikeTree(tree)) {
                tree.remove(block);
                for (Block log : tree) {
                    breakExtra(player, log, tool);
                }
            }
        }
    }

    /** Which side of the block the player is mining, so the 3x3 faces the right way. */
    private BlockFace faceOf(Player player, Block block) {
        RayTraceResult hit = player.rayTraceBlocks(6.0);
        if (hit != null && block.equals(hit.getHitBlock()) && hit.getHitBlockFace() != null) {
            return hit.getHitBlockFace();
        }
        float pitch = player.getLocation().getPitch();
        if (pitch > 50) {
            return BlockFace.UP;
        }
        if (pitch < -50) {
            return BlockFace.DOWN;
        }
        return player.getFacing().getOppositeFace();
    }

    private void breakExtra(Player player, Block target, ItemStack tool) {
        Material material = target.getType();
        if (material.isAir() || target.isLiquid() || material.getHardness() < 0
                || target.getState() instanceof Container || target.getState() instanceof CreatureSpawner) {
            return;
        }
        BlockBreakEvent event = new BlockBreakEvent(target, player);
        busy.add(player.getUniqueId());
        try {
            Bukkit.getPluginManager().callEvent(event);   // lets protection plugins say no
            if (!event.isCancelled()) {
                target.breakNaturally(tool);
            }
        } finally {
            busy.remove(player.getUniqueId());
        }
    }

    private Set<Block> findTree(Block start) {
        Set<Block> seen = new HashSet<>();
        Queue<Block> queue = new ArrayDeque<>();
        seen.add(start);
        queue.add(start);
        while (!queue.isEmpty() && seen.size() < MAX_TREE_LOGS) {
            Block current = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        Block next = current.getRelative(dx, dy, dz);
                        if (Tag.LOGS.isTagged(next.getType()) && seen.add(next)) {
                            queue.add(next);
                        }
                    }
                }
            }
        }
        return seen;
    }

    /** Only real trees (logs touching leaves) are chopped, so player-built log houses are safe. */
    private boolean looksLikeTree(Set<Block> logs) {
        for (Block log : logs) {
            for (BlockFace face : new BlockFace[]{BlockFace.UP, BlockFace.NORTH, BlockFace.SOUTH,
                    BlockFace.EAST, BlockFace.WEST}) {
                if (Tag.LEAVES.isTagged(log.getRelative(face).getType())) {
                    return true;
                }
            }
        }
        return false;
    }

    // ----------------------------------------------------- multitool: axe + shovel speed

    @EventHandler(ignoreCancelled = true)
    public void onDamage(BlockDamageEvent event) {
        ItemStack tool = event.getItemInHand();
        if (plugin.typeOf(tool) != SpecialType.MULTITOOL) {
            return;
        }
        Block block = event.getBlock();
        Material material = block.getType();
        boolean axeOrShovel = Tag.MINEABLE_AXE.isTagged(material) || Tag.MINEABLE_SHOVEL.isTagged(material);
        if (axeOrShovel && !block.isPreferredTool(tool) && material.getHardness() <= 3.0f) {
            // a pickaxe is slow on wood and dirt; with Efficiency V an axe/shovel is practically instant
            event.setInstaBreak(true);
        }
    }

    // ------------------------------------------------ bucket (27 water) and firework

    @EventHandler(priority = EventPriority.HIGH)
    public void onUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND && event.getHand() != EquipmentSlot.OFF_HAND) {
            return;
        }
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        Player player = event.getPlayer();
        EquipmentSlot hand = event.getHand();
        ItemStack item = player.getInventory().getItem(hand);
        SpecialType type = plugin.typeOf(item);
        if (type == SpecialType.BUCKET) {
            drainWater(event, player);
        } else if (type == SpecialType.FIREWORK) {
            keepFirework(player, hand, item.clone());
        }
    }

    private void drainWater(PlayerInteractEvent event, Player player) {
        event.setUseItemInHand(Event.Result.DENY);   // the bucket stays an empty bucket
        event.setCancelled(true);

        RayTraceResult hit = player.rayTraceBlocks(5.0, FluidCollisionMode.ALWAYS);
        if (hit == null || hit.getHitBlock() == null) {
            return;
        }
        Block center = hit.getHitBlock();
        if (center.getType() != Material.WATER && !isWaterlogged(center)) {
            return;
        }

        BlockBreakEvent permission = new BlockBreakEvent(center, player);
        busy.add(player.getUniqueId());
        try {
            Bukkit.getPluginManager().callEvent(permission);
        } finally {
            busy.remove(player.getUniqueId());
        }
        if (permission.isCancelled()) {
            return;
        }

        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    Block block = center.getRelative(dx, dy, dz);
                    if (block.getType() == Material.WATER) {
                        block.setType(Material.AIR, false);
                    } else if (block.getBlockData() instanceof Waterlogged waterlogged && waterlogged.isWaterlogged()) {
                        waterlogged.setWaterlogged(false);
                        block.setBlockData(waterlogged, false);
                    }
                }
            }
        }
        player.playSound(player.getLocation(), Sound.ITEM_BUCKET_FILL, 1f, 1f);
    }

    private boolean isWaterlogged(Block block) {
        return block.getBlockData() instanceof Waterlogged waterlogged && waterlogged.isWaterlogged();
    }

    /** Infinite firework: whatever the click used up is put back a tick later. */
    private void keepFirework(Player player, EquipmentSlot hand, ItemStack before) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            PlayerInventory inventory = player.getInventory();
            ItemStack now = inventory.getItem(hand);
            if (now == null || now.getType().isAir() || now.getAmount() < before.getAmount()) {
                inventory.setItem(hand, before);
            }
        });
    }
}
