package dev.specialitems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class SpecialPlugin extends JavaPlugin implements CommandExecutor {
    private static final TextColor PURPLE = TextColor.color(0xB300FF);

    private NamespacedKey typeKey;
    private NamespacedKey expiresKey;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        typeKey = new NamespacedKey(this, "special");
        expiresKey = new NamespacedKey(this, "expires");

        getServer().getPluginManager().registerEvents(new SpecialListener(this), this);
        PluginCommand command = getCommand("specialitems");
        if (command != null) {
            command.setExecutor(this);
        }
        // live countdown + self destruct, once a minute
        getServer().getScheduler().runTaskTimer(this, this::tick, 1200L, 1200L);
    }

    // ------------------------------------------------------------- creating items

    ItemStack create(SpecialType type) {
        double days = getConfig().getDouble("self-destruct-days", 3);
        long expires = days > 0 ? System.currentTimeMillis() + (long) (days * 86_400_000L) : 0L;

        ItemStack stack = new ItemStack(type.material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(plain(Component.text(type.displayName, PURPLE, TextDecoration.BOLD)));
        for (int i = 0; i < type.enchantments.length; i++) {
            meta.addEnchant(type.enchantments[i], type.levels[i], true);
        }
        if (meta instanceof FireworkMeta fireworkMeta) {
            fireworkMeta.setPower(1);
        }
        meta.getPersistentDataContainer().set(typeKey, PersistentDataType.STRING, type.id);
        if (expires > 0) {
            meta.getPersistentDataContainer().set(expiresKey, PersistentDataType.LONG, expires);
        }
        meta.lore(lore(type, expires));
        stack.setItemMeta(meta);
        return stack;
    }

    private List<Component> lore(SpecialType type, long expires) {
        List<Component> lore = new ArrayList<>();
        for (String line : type.abilities) {
            lore.add(plain(Component.text(line, NamedTextColor.WHITE)));
        }
        if (expires > 0) {
            lore.add(plain(Component.text("Self Destruct:", NamedTextColor.GRAY)));
            lore.add(plain(Component.text(timeLeft(expires - System.currentTimeMillis()), NamedTextColor.GRAY)));
        }
        return lore;
    }

    private static Component plain(Component component) {
        return component.decoration(TextDecoration.ITALIC, false);
    }

    private static String timeLeft(long millis) {
        long minutes = Math.max(0, millis) / 60_000;
        long days = minutes / 1440;
        long hours = (minutes % 1440) / 60;
        long mins = minutes % 60;
        StringBuilder text = new StringBuilder();
        if (days > 0) {
            text.append(days).append("d ");
        }
        if (hours > 0) {
            text.append(hours).append("h ");
        }
        if (mins > 0 || text.length() == 0) {
            text.append(mins).append("m ");
        }
        return text.toString().trim();
    }

    private static final PlainTextComponentSerializer PLAIN = PlainTextComponentSerializer.plainText();

    /**
     * Finds out which special item this is. Items made by /specialitems carry a hidden tag. Items given
     * by another plugin (like the crates) are recognised by their name and material instead.
     */
    SpecialType typeOf(ItemStack stack) {
        if (stack == null || stack.getType().isAir() || !stack.hasItemMeta()) {
            return null;
        }
        ItemMeta meta = stack.getItemMeta();
        SpecialType tagged = SpecialType.byId(meta.getPersistentDataContainer().get(typeKey, PersistentDataType.STRING));
        if (tagged != null) {
            return tagged;
        }
        Component name = meta.displayName();
        if (name == null) {
            return null;
        }
        String plain = PLAIN.serialize(name).trim();
        for (SpecialType type : SpecialType.values()) {
            if (type.material == stack.getType() && type.displayName.equalsIgnoreCase(plain)) {
                return type;
            }
        }
        return null;
    }

    // ----------------------------------------------- countdown and self destruct

    private void tick() {
        long now = System.currentTimeMillis();
        for (Player player : Bukkit.getOnlinePlayers()) {
            PlayerInventory inventory = player.getInventory();
            ItemStack[] contents = inventory.getContents();
            boolean changed = false;
            for (int slot = 0; slot < contents.length; slot++) {
                ItemStack stack = contents[slot];
                SpecialType type = typeOf(stack);
                if (type == null) {
                    continue;
                }
                ItemMeta current = stack.getItemMeta();
                PersistentDataContainer container = current.getPersistentDataContainer();
                if (!container.has(typeKey, PersistentDataType.STRING)) {
                    // came from the crates: tag it and start its self destruct timer now
                    double days = getConfig().getDouble("self-destruct-days", 3);
                    long stamp = days > 0 ? now + (long) (days * 86_400_000L) : 0L;
                    container.set(typeKey, PersistentDataType.STRING, type.id);
                    if (stamp > 0) {
                        container.set(expiresKey, PersistentDataType.LONG, stamp);
                    }
                    current.lore(lore(type, stamp));
                    stack.setItemMeta(current);
                    inventory.setItem(slot, stack);
                    continue;
                }
                Long expires = container.get(expiresKey, PersistentDataType.LONG);
                if (expires == null) {
                    continue;
                }
                if (now >= expires) {
                    inventory.setItem(slot, null);
                    player.sendMessage(Component.text("Your " + type.displayName + " self destructed.", NamedTextColor.RED));
                    continue;
                }
                ItemMeta meta = stack.getItemMeta();
                List<Component> fresh = lore(type, expires);
                if (!fresh.equals(meta.lore())) {
                    meta.lore(fresh);
                    stack.setItemMeta(meta);
                    inventory.setItem(slot, stack);
                }
            }
        }
    }

    // ------------------------------------------------------------------- command

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("specialitems.admin")) {
            sender.sendMessage(Component.text("You can't use that.", NamedTextColor.RED));
            return true;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("list")) {
            StringBuilder names = new StringBuilder();
            for (SpecialType type : SpecialType.values()) {
                names.append(type.id).append(", ");
            }
            sender.sendMessage(Component.text("Items: " + names.substring(0, names.length() - 2), NamedTextColor.AQUA));
            return true;
        }
        if (args.length < 3 || !args[0].equalsIgnoreCase("give")) {
            sender.sendMessage(Component.text("Usage: /specialitems give <player> <item> [amount]  |  /specialitems list",
                    NamedTextColor.YELLOW));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        SpecialType type = SpecialType.byId(args[2].toLowerCase(Locale.ROOT));
        if (target == null) {
            sender.sendMessage(Component.text("That player isn't online.", NamedTextColor.RED));
            return true;
        }
        if (type == null) {
            sender.sendMessage(Component.text("Unknown item. Use /specialitems list", NamedTextColor.RED));
            return true;
        }
        int amount = 1;
        if (args.length >= 4) {
            try {
                amount = Math.max(1, Math.min(64, Integer.parseInt(args[3])));
            } catch (NumberFormatException e) {
                sender.sendMessage(Component.text("Amount must be a number.", NamedTextColor.RED));
                return true;
            }
        }
        for (int i = 0; i < amount; i++) {
            for (ItemStack left : target.getInventory().addItem(create(type)).values()) {
                target.getWorld().dropItemNaturally(target.getLocation(), left);
            }
        }
        sender.sendMessage(Component.text("Gave " + amount + "x " + type.displayName + " to " + target.getName() + ".",
                NamedTextColor.GREEN));
        return true;
    }
}
