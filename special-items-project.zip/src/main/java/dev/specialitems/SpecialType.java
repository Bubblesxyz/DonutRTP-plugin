package dev.specialitems;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;

import java.util.Locale;

enum SpecialType {
    FIREWORK("firework", Material.FIREWORK_ROCKET, "SPECIAL FIREWORK",
            new String[]{"Flight Duration: 1", "Infinite firework"},
            new Enchantment[]{}, new int[]{}),
    DRILL("drill", Material.NETHERITE_PICKAXE, "SPECIAL DRILL",
            new String[]{"Breaks 9 Blocks at Once"},
            new Enchantment[]{Enchantment.EFFICIENCY, Enchantment.UNBREAKING, Enchantment.MENDING},
            new int[]{5, 3, 1}),
    BUCKET("bucket", Material.BUCKET, "SPECIAL BUCKET",
            new String[]{"Drains 27 Water At Once"},
            new Enchantment[]{}, new int[]{}),
    // The name must contain "SPECIAL SELL AXE": SKSell's sell-axe feature looks for exactly that.
    SELL_AXE("sellaxe", Material.NETHERITE_AXE, "SPECIAL SELL AXE",
            new String[]{"Instantly Sells All Items in A Chest"},
            new Enchantment[]{Enchantment.EFFICIENCY, Enchantment.UNBREAKING, Enchantment.MENDING},
            new int[]{5, 3, 1}),
    MULTITOOL("multitool", Material.NETHERITE_PICKAXE, "SPECIAL MULTITOOL",
            new String[]{"All Tools in One", "Works as Pickaxe, Axe & Shovel"},
            new Enchantment[]{Enchantment.FORTUNE, Enchantment.EFFICIENCY, Enchantment.UNBREAKING, Enchantment.MENDING},
            new int[]{3, 5, 3, 1}),
    AXE("axe", Material.NETHERITE_AXE, "SPECIAL AXE",
            new String[]{"Breaks Trees Instantly"},
            new Enchantment[]{Enchantment.SILK_TOUCH, Enchantment.EFFICIENCY, Enchantment.UNBREAKING, Enchantment.MENDING},
            new int[]{1, 5, 3, 1});

    final String id;
    final Material material;
    final String displayName;
    final String[] abilities;
    final Enchantment[] enchantments;
    final int[] levels;

    SpecialType(String id, Material material, String displayName, String[] abilities,
                Enchantment[] enchantments, int[] levels) {
        this.id = id;
        this.material = material;
        this.displayName = displayName;
        this.abilities = abilities;
        this.enchantments = enchantments;
        this.levels = levels;
    }

    static SpecialType byId(String id) {
        if (id == null) {
            return null;
        }
        String wanted = id.toLowerCase(Locale.ROOT);
        for (SpecialType type : values()) {
            if (type.id.equals(wanted)) {
                return type;
            }
        }
        return null;
    }
}
