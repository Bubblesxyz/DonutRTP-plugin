package com.duuchniuk.donutsmprtp;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/** /rtp: same as before, but opens the dialog menu instead of the chest menu. */
public final class RtpCommand implements CommandExecutor {
    private final DonutSmpRtpPlugin plugin;

    public RtpCommand(DonutSmpRtpPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Text.error("Only players can use this command."));
            return true;
        }

        plugin.tracker().recordMenuOrigin(player);

        try {
            RtpDialog.open(plugin, player);
        } catch (LinkageError e) {
            // Server too old for dialogs (needs Paper 1.21.7+): use the old chest menu.
            plugin.guiManager().openRtp(player);
        }
        return true;
    }
}
