package com.duuchniuk.donutsmprtp;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickCallback;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/** The new RTP menu: Minecraft's native dialog screen (Paper 1.21.7+). */
final class RtpDialog {
    private static final int BUTTON_WIDTH = 310;

    private RtpDialog() {
    }

    static void open(DonutSmpRtpPlugin plugin, Player player) {
        List<ActionButton> buttons = new ArrayList<>();

        for (RtpDimension dimension : RtpDimension.values()) {
            String name = switch (dimension) {
                case OVERWORLD -> "Overworld";
                case NETHER -> "Nether";
                case END -> "End";
            };

            boolean locked = !plugin.configManager().settings(dimension).enabled();

            if (locked) {
                buttons.add(ActionButton.builder(Component.text(name + " (Locked)", NamedTextColor.GRAY))
                        .width(BUTTON_WIDTH)
                        .build());
            } else {
                RtpDimension target = dimension;
                DialogAction action = DialogAction.customClick((view, audience) -> {
                    if (audience instanceof Player clicker) {
                        // The original menu started the teleport on the main thread too.
                        Bukkit.getScheduler().runTask(plugin, () -> plugin.tracker().start(clicker, target));
                    }
                }, ClickCallback.Options.builder().uses(ClickCallback.UNLIMITED_USES).build());

                buttons.add(ActionButton.builder(Component.text(name))
                        .width(BUTTON_WIDTH)
                        .action(action)
                        .build());
            }
        }

        ActionButton close = ActionButton.builder(Component.text("Close"))
                .width(BUTTON_WIDTH)
                .build();

        Dialog dialog = Dialog.create(factory -> factory.empty()
                .base(DialogBase.builder(Component.text("Random Teleport"))
                        .canCloseWithEscape(true)
                        .build())
                .type(DialogType.multiAction(buttons, close, 1)));

        player.showDialog(dialog);
    }
}
