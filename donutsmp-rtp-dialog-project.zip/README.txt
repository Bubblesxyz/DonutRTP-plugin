Only two things change: RtpCommand (opens the new menu) and the new RtpDialog (the menu).
Everything else comes from your original jar, untouched. /adminrtp stays a chest menu.
Needs Paper 1.21.7 or newer. On older servers /rtp falls back to the old menu.

1. Upload all of these files to a new GitHub repo (keep the folders).
   If the ".github" folder doesn't upload, make the file by hand:
   Add file > Create new file > name it  .github/workflows/build.yml  > paste build.yml.
2. Open the Actions tab, wait for the green check, open the run,
   download "donutsmp-rtp-dialog-jar" at the bottom.
3. Unzip it and put the .jar in your server's plugins folder.
