# DonutRTP 1.0.0 (Paper 1.21.11)

A standalone plugin, separate from DrDonutMenu. Only feature: /rtp.

UNTESTED: written without access to compile against the real Paper API. Syntax-checked
only (no real errors found). Build it and report any compile errors so they can be fixed.

IMPORTANT: remove your old third-party RTP plugin first. This one also uses /rtp and
the two will conflict if both are installed, same as before.

Build the jar:
- Computer: install JDK 21 + Maven, run `mvn package`. Jar = target/DonutRTP.jar
- No install: upload this whole folder to a new GitHub repo (include the hidden
  .github folder). Actions tab -> "Build plugin" -> download the DonutRTP artifact.

Commands:
- /rtp - opens the menu (Overworld / Nether / End)
- /rtp overworld | /rtp nether | /rtp end - teleports directly

Settings live in plugins/DonutRTP/config.yml: cooldown, teleport delay, each world's
radius, and enabled: true/false to lock/unlock a world (End is locked by default).
