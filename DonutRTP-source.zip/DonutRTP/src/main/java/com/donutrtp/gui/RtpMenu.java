package com.donutrtp.gui;

import com.donutrtp.DonutRTP;
import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;

import java.util.List;

/** /rtp with no args - single-column choice of Overworld / Nether / End, gray vanilla buttons, no resource pack needed. */
public final class RtpMenu {

    private static final int WIDTH = 320;

    private RtpMenu() {}

    public static void open(DonutRTP plugin, Player player) {
        List<ActionButton> buttons = List.of(
                worldButton(plugin, "overworld", "Overworld"),
                worldButton(plugin, "nether", "Nether"),
                worldButton(plugin, "end", "End")
        );
        ActionButton close = ActionButton.create(Component.text("Close"), null, WIDTH,
                DialogAction.staticAction(ClickEvent.suggestCommand("")));

        Dialog dialog = Dialog.create(builder -> builder.empty()
                .base(DialogBase.builder(Component.text("Random Teleport")).canCloseWithEscape(true).build())
                .type(DialogType.multiAction(buttons, close, 1)));
        player.showDialog(dialog);
    }

    private static ActionButton worldButton(DonutRTP plugin, String key, String label) {
        boolean enabled = plugin.getConfig().getBoolean("worlds." + key + ".enabled", true);
        Component text = enabled ? Component.text(label)
                : Component.text(label + " (Locked)", NamedTextColor.DARK_GRAY);
        return ActionButton.create(text, null, WIDTH,
                DialogAction.staticAction(ClickEvent.runCommand("/rtp " + key)));
    }
}
