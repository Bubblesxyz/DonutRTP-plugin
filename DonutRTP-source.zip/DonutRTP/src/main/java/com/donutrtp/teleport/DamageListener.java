package com.donutrtp.teleport;

import com.donutrtp.DonutRTP;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

/** Cancels a player's RTP countdown if they take damage, per warmup.cancel-on-damage. */
public final class DamageListener implements Listener {

    private final DonutRTP plugin;

    public DamageListener(DonutRTP plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p) {
            plugin.rtp().cancelOnDamage(p);
        }
    }
}
