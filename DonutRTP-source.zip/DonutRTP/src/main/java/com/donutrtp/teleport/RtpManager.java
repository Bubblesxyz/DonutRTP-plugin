package com.donutrtp.teleport;

import com.donutrtp.DonutRTP;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;

public final class RtpManager {

    private final DonutRTP plugin;
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();
    private final Set<UUID> pending = ConcurrentHashMap.newKeySet();

    public RtpManager(DonutRTP plugin) {
        this.plugin = plugin;
    }

    /** @param worldKey one of "overworld", "nether", "end" - see worlds in config.yml */
    public void start(Player player, String worldKey) {
        FileConfiguration c = plugin.getConfig();
        String base = "worlds." + worldKey;
        if (!c.contains(base)) {
            plugin.error(player, "Unknown RTP destination.");
            return;
        }
        if (!c.getBoolean(base + ".enabled", true)) {
            plugin.error(player, c.getString(base + ".display-name", worldKey) + " is currently closed.");
            return;
        }
        World world = Bukkit.getWorld(c.getString(base + ".world", worldKey));
        if (world == null) {
            plugin.error(player, "That world isn't loaded.");
            return;
        }

        UUID id = player.getUniqueId();
        if (pending.contains(id)) {
            plugin.error(player, "You already have a teleport pending.");
            return;
        }
        if (!player.hasPermission("donutrtp.nocooldown")) {
            Long last = cooldowns.get(id);
            long cooldownMs = c.getLong("cooldown-seconds", 60) * 1000L;
            if (last != null) {
                long left = last + cooldownMs - System.currentTimeMillis();
                if (left > 0) {
                    plugin.error(player, "You must wait " + ((left + 999) / 1000) + " seconds.");
                    return;
                }
            }
        }

        int box = Math.max(1, c.getInt(base + ".box", 10000));

        pending.add(id);
        plugin.info(player, "Searching for a safe location...");
        search(world, box, c.getInt("max-attempts", 20), loc -> {
            if (!player.isOnline()) {
                pending.remove(id);
                return;
            }
            if (loc == null) {
                pending.remove(id);
                plugin.error(player, "Could not find a safe location, please try again.");
                return;
            }
            countdown(player, loc);
        });
    }

    private void countdown(Player player, Location target) {
        UUID id = player.getUniqueId();
        int delay = plugin.getConfig().getInt("teleport-delay-seconds", 3);
        if (delay <= 0) {
            finish(player, target);
            return;
        }
        Location start = player.getLocation();
        new BukkitRunnable() {
            int left = delay;

            @Override
            public void run() {
                if (!player.isOnline()) {
                    pending.remove(id);
                    cancel();
                    return;
                }
                Location now = player.getLocation();
                if (now.getWorld() != start.getWorld() || now.distanceSquared(start) > 0.25) {
                    pending.remove(id);
                    plugin.error(player, "Teleport cancelled, you moved.");
                    cancel();
                    return;
                }
                if (left <= 0) {
                    cancel();
                    finish(player, target);
                    return;
                }
                player.sendActionBar(net.kyori.adventure.text.Component.text(
                        "Teleporting in " + left + " seconds. Don't move!",
                        net.kyori.adventure.text.format.NamedTextColor.YELLOW));
                left--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private void finish(Player player, Location target) {
        UUID id = player.getUniqueId();
        target.setYaw(player.getLocation().getYaw());
        player.teleportAsync(target).thenAccept(ok -> {
            pending.remove(id);
            if (Boolean.TRUE.equals(ok)) {
                cooldowns.put(id, System.currentTimeMillis());
                plugin.ok(player, "Teleported to " + target.getBlockX() + ", " + target.getBlockY()
                        + ", " + target.getBlockZ() + "!");
                plugin.whoosh(player);
            }
        }).exceptionally(ex -> {
            pending.remove(id);
            plugin.getLogger().severe("RTP teleport failed: " + ex);
            ex.printStackTrace();
            plugin.error(player, "Teleport failed, check the server console.");
            return null;
        });
    }

    private void search(World world, int box, int attemptsLeft, Consumer<Location> done) {
        if (attemptsLeft <= 0) {
            done.accept(null);
            return;
        }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        Location spawn = world.getSpawnLocation();
        // X and Z each picked independently in [-box, +box], so the point can land anywhere
        // in that square - not just in a ring at a fixed distance.
        int x = spawn.getBlockX() + r.nextInt(-box, box + 1);
        int z = spawn.getBlockZ() + r.nextInt(-box, box + 1);

        world.getChunkAtAsync(x >> 4, z >> 4).thenAccept(chunk ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    Location loc = check(world, x, z);
                    if (loc != null) done.accept(loc);
                    else search(world, box, attemptsLeft - 1, done);
                })).exceptionally(ex -> {
                    plugin.getLogger().severe("RTP chunk load failed: " + ex);
                    ex.printStackTrace();
                    done.accept(null);
                    return null;
                });
    }

    private Location check(World w, int x, int z) {
        if (!w.getWorldBorder().isInside(new Location(w, x, 64, z))) return null;
        int y = w.getHighestBlockYAt(x, z);
        Block ground = w.getBlockAt(x, y, z);
        Material t = ground.getType();
        if (ground.isLiquid() || !t.isSolid() || Tag.LEAVES.isTagged(t)
                || t == Material.MAGMA_BLOCK || t == Material.CACTUS || t == Material.CAMPFIRE
                || t == Material.SOUL_CAMPFIRE || t == Material.SWEET_BERRY_BUSH) return null;
        Block feet = w.getBlockAt(x, y + 1, z);
        Block head = w.getBlockAt(x, y + 2, z);
        if (!feet.isPassable() || !head.isPassable() || feet.isLiquid() || head.isLiquid()) return null;
        return new Location(w, x + 0.5, y + 1, z + 0.5);
    }
}
