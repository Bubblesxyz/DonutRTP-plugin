package com.donutrtp;

import com.donutrtp.commands.RtpCommand;
import com.donutrtp.teleport.DamageListener;
import com.donutrtp.teleport.RtpManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Sound;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class DonutRTP extends JavaPlugin {

    private RtpManager rtp;
    private Component prefix;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        prefix = LegacyComponentSerializer.legacyAmpersand()
                .deserialize(getConfig().getString("messages.prefix", "&6&lDonut RTP &8» &r"));
        rtp = new RtpManager(this);

        PluginCommand cmd = getCommand("rtp");
        if (cmd != null) cmd.setExecutor(new RtpCommand(this));
        getServer().getPluginManager().registerEvents(new DamageListener(this), this);

        getLogger().warning("DonutRTP v" + getPluginMeta().getVersion() + " loaded - if you don't see this exact"
                + " version number on startup, the server is running an old jar.");
    }

    public RtpManager rtp() { return rtp; }

    public void send(org.bukkit.command.CommandSender to, Component c) { to.sendMessage(prefix.append(c)); }
    public void info(org.bukkit.command.CommandSender to, String text) { send(to, Component.text(text, NamedTextColor.YELLOW)); }
    public void ok(org.bukkit.command.CommandSender to, String text) { send(to, Component.text(text, NamedTextColor.GREEN)); }
    public void error(org.bukkit.command.CommandSender to, String text) { send(to, Component.text(text, NamedTextColor.RED)); }

    public void whoosh(Player p) {
        p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.6f, 1.0f);
    }
}
