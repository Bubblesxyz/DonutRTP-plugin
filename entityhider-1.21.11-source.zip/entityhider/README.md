# Entity Hider (Fabric, Minecraft 1.21.11, client-side)
Uses Mojang mappings (the default in the Fabric template for 1.21.11).

## Build
1. https://fabricmc.net/develop/template/ -> Minecraft 1.21.11, Mojang mappings, Fabric API on. Unzip.
2. Delete the template's example sources, copy `src/main/java` and `src/main/resources` from here over it.
3. In build.gradle add:
   repositories { maven { url = "https://maven.terraformersmc.com/releases/" } }
   dependencies { modImplementation "com.terraformersmc:modmenu:17.0.0" }
4. ./gradlew build -> jar in build/libs/ (not the -sources one).
5. Put it in mods/ with Fabric API and Mod Menu.

## Use
- J toggles (rebind in Controls).
- Mods menu -> Entity Hider -> Configure.
