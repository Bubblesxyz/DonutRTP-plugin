package com.example.entityhider;

import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;

public class Config {
    public static boolean enabled = true;
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("entityhider.txt");

    public static void load() {
        try {
            if (Files.exists(FILE)) enabled = Boolean.parseBoolean(Files.readString(FILE).trim());
        } catch (Exception ignored) {}
    }

    public static void save() {
        try { Files.writeString(FILE, Boolean.toString(enabled)); } catch (Exception ignored) {}
    }
}
