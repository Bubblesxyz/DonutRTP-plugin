package com.example.entityhider;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ConfigScreen extends Screen {
    private final Screen parent;

    public ConfigScreen(Screen parent) {
        super(Component.literal("Entity Hider"));
        this.parent = parent;
    }

    private Component label() {
        return Component.literal("Hide entities: " + (Config.enabled ? "ON" : "OFF"));
    }

    @Override
    protected void init() {
        addRenderableWidget(Button.builder(label(), b -> {
            Config.enabled = !Config.enabled;
            Config.save();
            b.setMessage(label());
        }).bounds(width / 2 - 100, height / 2 - 10, 200, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(width / 2 - 100, height / 2 + 20, 200, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        g.drawCenteredString(font, title, width / 2, height / 2 - 40, 0xFFFFFFFF);
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }
}
