# Item Vanisher (1.21.11 Fabric port)
Press V (rebindable) to toggle rendering of dropped items. State persists in config/item-vanisher.json.

## Build
1. Easiest: download the Fabric example mod for 1.21.11 from https://fabricmc.net/develop/template,
   then replace its src/ folder, fabric.mod.json, build.gradle and gradle.properties with these.
   (This gives you the gradle wrapper, which I could not generate offline.)
2. ./gradlew build  ->  build/libs/item-vanisher-1.1.0.jar
Needs JDK 21 and Fabric API for 1.21.11 installed in the game.
