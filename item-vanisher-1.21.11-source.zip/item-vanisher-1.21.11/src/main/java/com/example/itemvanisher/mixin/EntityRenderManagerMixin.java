package com.example.itemvanisher.mixin;

import com.example.itemvanisher.IVConfig;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Culls dropped items before any render state is built, so model, shadow and
 * hitbox all disappear. Hooks shouldRender, which survives the 1.21.2+ and
 * 1.21.9+ render-state/submit refactors that broke the old render() hooks.
 */
@Mixin(EntityRenderManager.class)
public class EntityRenderManagerMixin {
	@Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
	private void itemvanisher$hideItems(Entity entity, Frustum frustum, double x, double y, double z,
										CallbackInfoReturnable<Boolean> cir) {
		if (entity instanceof ItemEntity && !IVConfig.get().render) {
			cir.setReturnValue(false);
		}
	}
}
