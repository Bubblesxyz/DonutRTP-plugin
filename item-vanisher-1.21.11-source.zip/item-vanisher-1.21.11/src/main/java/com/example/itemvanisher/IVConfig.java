package com.example.itemvanisher;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Tiny JSON config: { "render": true } in config/item-vanisher.json */
public final class IVConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("item-vanisher.json");
	private static IVConfig instance;

	public boolean render = true;

	public static IVConfig get() {
		if (instance == null) instance = load();
		return instance;
	}

	private static IVConfig load() {
		try {
			if (Files.exists(FILE)) {
				IVConfig c = GSON.fromJson(Files.readString(FILE), IVConfig.class);
				if (c != null) return c;
			}
		} catch (Exception e) {
			System.err.println("[item-vanisher] Failed to read config, using defaults: " + e);
		}
		IVConfig c = new IVConfig();
		c.save();
		return c;
	}

	public void save() {
		try {
			Files.writeString(FILE, GSON.toJson(this));
		} catch (IOException e) {
			System.err.println("[item-vanisher] Failed to save config: " + e);
		}
	}
}
