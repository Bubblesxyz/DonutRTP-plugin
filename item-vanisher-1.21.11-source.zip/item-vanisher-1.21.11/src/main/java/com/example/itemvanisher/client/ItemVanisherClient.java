package com.example.itemvanisher.client;

import com.example.itemvanisher.IVConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class ItemVanisherClient implements ClientModInitializer {
	private static final KeyBinding.Category CATEGORY =
			KeyBinding.Category.create(Identifier.of("item-vanisher", "main"));

	private static KeyBinding toggleKey;

	@Override
	public void onInitializeClient() {
		IVConfig.get(); // load early

		toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.item-vanisher.toggle",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_V,
				CATEGORY
		));

		ClientTickEvents.START_CLIENT_TICK.register(client -> {
			while (toggleKey.wasPressed()) {
				IVConfig cfg = IVConfig.get();
				cfg.render = !cfg.render;
				cfg.save();
				if (client.player != null) {
					client.player.sendMessage(
							Text.translatable("item-vanisher.text.actionbar." + cfg.render), true);
				}
			}
		});
	}
}
