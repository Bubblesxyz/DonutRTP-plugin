package com.mediasmp.sellbutton;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** The sell menu: 54 slots, slots 0-52 are free for items, slot 53 is the sell button. */
final class SellMenu implements Listener {

    static final int SIZE = 54;
    static final int BUTTON = 53;

    static final class Holder implements InventoryHolder {
        Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private final SellButtonPlugin plugin;
    /** Players with the menu open. Read from the packet thread, so it must be thread-safe. */
    private final Set<UUID> viewers = ConcurrentHashMap.newKeySet();

    SellMenu(SellButtonPlugin plugin) {
        this.plugin = plugin;
    }

    Set<UUID> viewers() {
        return viewers;
    }

    void open(Player p) {
        Holder holder = new Holder();
        Inventory inv = Bukkit.createInventory(holder, SIZE, Text.c(plugin.getConfig().getString("menu.title", "Sell")));
        holder.inv = inv;
        refreshButton(inv);
        viewers.add(p.getUniqueId());
        p.openInventory(inv);
        sound(p, "open");
    }

    void closeAll() {
        for (UUID id : new ArrayList<>(viewers)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.closeInventory();
        }
    }

    // ------------------------------------------------------------------ button

    private Material buttonMaterial() {
        Material m = Material.matchMaterial(plugin.getConfig().getString("menu.button.material", "LIME_STAINED_GLASS_PANE"));
        return m == null ? Material.LIME_STAINED_GLASS_PANE : m;
    }

    private double total(Inventory inv) {
        PriceTable prices = plugin.prices();
        double sum = 0;
        for (int i = 0; i < BUTTON; i++) {
            PriceTable.Appraisal a = prices.appraise(inv.getItem(i));
            if (a != null) sum += a.value();
        }
        return prices.payout(sum);
    }

    private void refreshButton(Inventory inv) {
        String total = Text.money(total(inv));
        ItemStack button = new ItemStack(buttonMaterial());
        ItemMeta meta = button.getItemMeta();
        meta.displayName(Text.c(plugin.getConfig().getString("menu.button.name", "&a$%total%").replace("%total%", total)));
        List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
        for (String line : plugin.getConfig().getStringList("menu.button.lore")) {
            lore.add(Text.c(line.replace("%total%", total)));
        }
        meta.lore(lore);
        button.setItemMeta(meta);
        inv.setItem(BUTTON, button);
    }

    // ----------------------------------------------------------------- selling

    private void sell(Player p, Inventory inv) {
        PriceTable prices = plugin.prices();
        double sum = 0;
        int items = 0;
        List<Integer> slots = new ArrayList<>();
        for (int i = 0; i < BUTTON; i++) {
            PriceTable.Appraisal a = prices.appraise(inv.getItem(i));
            if (a == null) continue;
            sum += a.value();
            items += a.items();
            slots.add(i);
        }
        double payout = prices.payout(sum);

        if (slots.isEmpty() || payout <= 0) {
            p.sendMessage(plugin.message("nothing"));
            sound(p, "rejected");
            return;
        }
        Economy eco = plugin.economy();
        if (eco == null) {
            p.sendMessage(plugin.message("no-economy"));
            sound(p, "rejected");
            return;
        }
        EconomyResponse r = eco.depositPlayer(p, payout);
        if (!r.transactionSuccess()) {
            p.sendMessage(plugin.message("payment-failed"));
            sound(p, "rejected");
            return;
        }

        // Paid - now take the items. Anything unsellable stays in the menu.
        for (int slot : slots) inv.setItem(slot, null);
        refreshButton(inv);
        p.sendMessage(plugin.message("sold", "%items%", String.valueOf(items), "%price%", Text.money(payout)));
        sound(p, "sold");
    }

    private void sound(Player p, String key) {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("sounds." + key);
        if (s == null) return;
        String name = s.getString("sound", "");
        if (name.isEmpty()) return;
        p.playSound(p.getLocation(), name, (float) s.getDouble("volume", 1.0), (float) s.getDouble("pitch", 1.0));
    }

    // ------------------------------------------------------------------ events

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder)) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;

        if (e.getRawSlot() == BUTTON) {
            e.setCancelled(true);
            switch (e.getClick()) {
                case LEFT, RIGHT, SHIFT_LEFT, SHIFT_RIGHT -> sell(p, top);
                default -> { }
            }
            return;
        }

        // A double-click would gather every matching item into the cursor, button included.
        if (e.getAction() == InventoryAction.COLLECT_TO_CURSOR
                && e.getCursor() != null && e.getCursor().getType() == buttonMaterial()) {
            e.setCancelled(true);
            return;
        }

        Bukkit.getScheduler().runTask(plugin, () -> refreshButton(top));
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder)) return;
        if (e.getRawSlots().contains(BUTTON)) {
            e.setCancelled(true);
            return;
        }
        Bukkit.getScheduler().runTask(plugin, () -> refreshButton(top));
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        Inventory inv = e.getInventory();
        if (!(inv.getHolder() instanceof Holder)) return;
        if (!(e.getPlayer() instanceof Player p)) return;
        viewers.remove(p.getUniqueId());

        // Give back everything that was not sold.
        for (int i = 0; i < BUTTON; i++) {
            ItemStack s = inv.getItem(i);
            if (s == null || s.getType().isAir()) continue;
            inv.setItem(i, null);
            Map<Integer, ItemStack> left = p.getInventory().addItem(s);
            for (ItemStack rest : left.values()) {
                p.getWorld().dropItemNaturally(p.getLocation(), rest);
            }
        }
    }
}
