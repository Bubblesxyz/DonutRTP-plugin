package com.mediasmp.sellbutton;

import org.bukkit.configuration.file.FileConfiguration;

import java.util.List;

/** The worth-display section of config.yml. */
record WorthSettings(boolean enabled, boolean includePlayerInventory,
                     List<String> single, List<String> stack, List<String> unsellable) {

    static WorthSettings load(FileConfiguration c) {
        return new WorthSettings(
                c.getBoolean("worth-display.enabled", true),
                c.getBoolean("worth-display.include-player-inventory", true),
                c.getStringList("worth-display.single"),
                c.getStringList("worth-display.stack"),
                c.getStringList("worth-display.unsellable"));
    }
}
