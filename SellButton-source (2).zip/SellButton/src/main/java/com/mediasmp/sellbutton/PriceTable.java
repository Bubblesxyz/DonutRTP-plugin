package com.mediasmp.sellbutton;

import org.bukkit.Material;
import org.bukkit.block.BlockState;
import org.bukkit.block.ShulkerBox;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Logger;

/** Reads prices.yml and works out what an item stack is worth. Immutable after load. */
final class PriceTable {

    /** value = what the stack is worth, items = how many items that covers (shulker contents included). */
    record Appraisal(double value, int items) {}

    private record Rule(List<String> words, double price) {}

    private final Map<Material, Double> explicit = new EnumMap<>(Material.class);
    private final List<String> neverSell = new ArrayList<>();
    private final List<Rule> rules = new ArrayList<>();
    private boolean autoEnabled;
    private double defaultPrice;

    private boolean allowRenamed, allowEnchanted, refusePluginItems, refuseDamaged, scaleDamaged, roundDown;

    static PriceTable load(FileConfiguration prices, FileConfiguration config, Logger log) {
        PriceTable t = new PriceTable();

        ConfigurationSection cats = prices.getConfigurationSection("categories");
        if (cats != null) {
            for (String cat : cats.getKeys(false)) {
                ConfigurationSection items = cats.getConfigurationSection(cat + ".items");
                if (items == null) continue;
                for (String key : items.getKeys(false)) {
                    Material m = Material.matchMaterial(key);
                    if (m == null) {
                        log.warning("prices.yml: unknown item '" + key + "' in category '" + cat + "' - skipped.");
                        continue;
                    }
                    t.explicit.put(m, items.getDouble(key));
                }
            }
        }

        t.autoEnabled = prices.getBoolean("auto-pricing.enabled", false);
        t.defaultPrice = prices.getDouble("auto-pricing.default-price", 1);
        for (String s : prices.getStringList("auto-pricing.never-sell")) {
            t.neverSell.add(s.toLowerCase(Locale.ROOT));
        }
        for (Map<?, ?> raw : prices.getMapList("auto-pricing.rules")) {
            Object contains = raw.get("contains");
            Object price = raw.get("price");
            if (!(contains instanceof List<?> list) || !(price instanceof Number n)) continue;
            List<String> words = new ArrayList<>();
            for (Object o : list) words.add(String.valueOf(o).toLowerCase(Locale.ROOT));
            t.rules.add(new Rule(words, n.doubleValue()));
        }

        t.allowRenamed = config.getBoolean("selling.allow-renamed", true);
        t.allowEnchanted = config.getBoolean("selling.allow-enchanted", true);
        t.refusePluginItems = config.getBoolean("selling.refuse-plugin-items", true);
        t.refuseDamaged = config.getBoolean("selling.refuse-damaged", false);
        t.scaleDamaged = config.getBoolean("selling.scale-damaged-price", true);
        t.roundDown = config.getBoolean("selling.round-payout-down", true);
        return t;
    }

    /** Price of one item of this type, or -1 if it cannot be sold. */
    private double unitPrice(Material m) {
        Double listed = explicit.get(m);
        if (listed != null) return listed;
        if (!autoEnabled || m.isAir() || !m.isItem()) return -1;

        String name = m.name().toLowerCase(Locale.ROOT).replace('_', ' ');
        for (String s : neverSell) {
            if (name.contains(s)) return -1;
        }
        for (Rule r : rules) {
            for (String w : r.words()) {
                if (name.contains(w)) return r.price();
            }
        }
        return defaultPrice;
    }

    /** What a stack is worth, or null if it cannot be sold. */
    Appraisal appraise(ItemStack item) {
        if (item == null || item.getType().isAir()) return null;
        double unit = unitPrice(item.getType());
        if (unit <= 0) return null;

        double factor = 1;
        double inside = 0;
        int insideItems = 0;

        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            if (!allowRenamed && meta.hasDisplayName()) return null;
            if (!allowEnchanted && (meta.hasEnchants()
                    || (meta instanceof EnchantmentStorageMeta es && es.hasStoredEnchants()))) return null;
            if (refusePluginItems && !meta.getPersistentDataContainer().getKeys().isEmpty()) return null;

            if (meta instanceof Damageable d && d.hasDamage()) {
                if (refuseDamaged) return null;
                if (scaleDamaged) {
                    int max = d.hasMaxDamage() ? d.getMaxDamage() : item.getType().getMaxDurability();
                    if (max > 0) factor = Math.max(0, (max - d.getDamage()) / (double) max);
                }
            }

            // Shulker boxes are sold with everything inside. If anything inside cannot be
            // sold, the whole box is refused so nobody loses items by accident.
            if (meta instanceof BlockStateMeta b && b.hasBlockState()) {
                BlockState state = b.getBlockState();
                if (state instanceof ShulkerBox box) {
                    for (ItemStack in : box.getInventory().getContents()) {
                        if (in == null || in.getType().isAir()) continue;
                        Appraisal a = appraise(in);
                        if (a == null) return null;
                        inside += a.value();
                        insideItems += a.items();
                    }
                }
            }
        }

        double value = unit * factor * item.getAmount() + inside;
        if (value <= 0) return null;
        return new Appraisal(value, item.getAmount() + insideItems);
    }

    /** Applies the round-payout-down setting, to cents. */
    double payout(double total) {
        return roundDown ? Math.floor(total * 100) / 100.0 : Math.round(total * 100) / 100.0;
    }
}
