package com.mediasmp.sellbutton;

import net.kyori.adventure.text.Component;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public final class SellButtonPlugin extends JavaPlugin implements CommandExecutor {

    private volatile PriceTable prices;
    private volatile WorthSettings worth;
    private SellMenu menu;
    private Economy economy;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadAll();

        menu = new SellMenu(this);
        getServer().getPluginManager().registerEvents(menu, this);
        getCommand("sell").setExecutor(this);

        if (getServer().getPluginManager().getPlugin("ProtocolLib") != null) {
            WorthTooltip.register(this);
        } else {
            getLogger().warning("ProtocolLib not found - item worth tooltips are disabled. Install ProtocolLib to enable them.");
        }
    }

    @Override
    public void onDisable() {
        if (menu != null) menu.closeAll(); // gives unsold items back
    }

    void loadAll() {
        reloadConfig();
        File file = new File(getDataFolder(), "prices.yml");
        if (!file.exists()) saveResource("prices.yml", false);
        prices = PriceTable.load(YamlConfiguration.loadConfiguration(file), getConfig(), getLogger());
        worth = WorthSettings.load(getConfig());
    }

    PriceTable prices() { return prices; }

    WorthSettings worthSettings() { return worth; }

    SellMenu menu() { return menu; }

    Economy economy() {
        if (economy == null) {
            RegisteredServiceProvider<Economy> reg = getServer().getServicesManager().getRegistration(Economy.class);
            if (reg != null) economy = reg.getProvider();
        }
        return economy;
    }

    /** A message from config.yml with the prefix in front. */
    Component message(String key, String... replacements) {
        String raw = getConfig().getString("messages." + key, "");
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            raw = raw.replace(replacements[i], replacements[i + 1]);
        }
        return Text.c(getConfig().getString("messages.prefix", "") + raw);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("sellbutton.reload")) {
                sender.sendMessage(message("no-permission"));
                return true;
            }
            loadAll();
            sender.sendMessage(message("reloaded"));
            return true;
        }
        if (!(sender instanceof Player p)) {
            sender.sendMessage(Text.c(getConfig().getString("messages.players-only", "Only players can use this.")));
            return true;
        }
        if (!p.hasPermission("sellbutton.use")) {
            p.sendMessage(message("no-permission"));
            return true;
        }
        menu.open(p);
        return true;
    }
}
