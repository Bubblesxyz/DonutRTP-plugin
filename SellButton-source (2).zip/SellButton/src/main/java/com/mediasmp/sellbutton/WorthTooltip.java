package com.mediasmp.sellbutton;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.events.ListenerPriority;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Adds "Worth: $X" lines to the tooltip of items shown in the sell menu.
 * Only the packets sent to the player are changed - the real items never get the lore,
 * so nothing can leak into the player's inventory and stacking is unaffected.
 */
final class WorthTooltip extends PacketAdapter {

    private final SellButtonPlugin plugin;

    private WorthTooltip(SellButtonPlugin plugin) {
        super(plugin, ListenerPriority.NORMAL,
                PacketType.Play.Server.SET_SLOT, PacketType.Play.Server.WINDOW_ITEMS);
        this.plugin = plugin;
    }

    static void register(SellButtonPlugin plugin) {
        ProtocolLibrary.getProtocolManager().addPacketListener(new WorthTooltip(plugin));
    }

    @Override
    public void onPacketSending(PacketEvent e) {
        WorthSettings s = plugin.worthSettings();
        if (!s.enabled()) return;

        Player player = e.getPlayer();
        if (!plugin.menu().viewers().contains(player.getUniqueId())) return;

        PacketContainer packet = e.getPacket().deepClone();
        int window = packet.getIntegers().read(0);
        if (window <= 0) return; // 0 is the player's own inventory screen

        if (e.getPacketType() == PacketType.Play.Server.SET_SLOT) {
            int slot = packet.getIntegers().read(2);
            if (!eligible(slot, s)) return;
            ItemStack out = decorate(packet.getItemModifier().read(0), s);
            if (out == null) return;
            packet.getItemModifier().write(0, out);
        } else {
            List<ItemStack> items = new ArrayList<>(packet.getItemListModifier().read(0));
            for (int i = 0; i < items.size(); i++) {
                if (!eligible(i, s)) continue;
                ItemStack out = decorate(items.get(i), s);
                if (out != null) items.set(i, out);
            }
            packet.getItemListModifier().write(0, items);
        }
        e.setPacket(packet);
    }

    /** Slots 0-52 are the menu, 53 is the button, 54+ is the player's inventory. */
    private boolean eligible(int slot, WorthSettings s) {
        if (slot < 0 || slot == SellMenu.BUTTON) return false;
        return slot < SellMenu.BUTTON || s.includePlayerInventory();
    }

    private ItemStack decorate(ItemStack item, WorthSettings s) {
        if (item == null || item.getType().isAir()) return null;

        PriceTable.Appraisal a = plugin.prices().appraise(item);
        List<String> lines;
        String worth = "0";
        String each = "0";
        if (a == null) {
            lines = s.unsellable();
        } else {
            worth = Text.money(a.value());
            each = Text.money(a.value() / Math.max(1, item.getAmount()));
            lines = item.getAmount() > 1 ? s.stack() : s.single();
        }
        if (lines.isEmpty()) return null;

        ItemStack copy = item.clone();
        ItemMeta meta = copy.getItemMeta();
        if (meta == null) return null;

        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        for (String line : lines) {
            lore.add(Text.c(line
                    .replace("%worth%", worth)
                    .replace("%total%", worth)
                    .replace("%each%", each)
                    .replace("%amount%", String.valueOf(item.getAmount()))));
        }
        meta.lore(lore);
        copy.setItemMeta(meta);
        return copy;
    }
}
