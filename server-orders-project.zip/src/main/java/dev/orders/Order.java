package dev.orders;

import org.bukkit.Material;

import java.util.UUID;

final class Order {
    final UUID id;
    final UUID owner;
    final String ownerName;
    final Material material;
    final int amount;
    final double price;
    final long createdAt;
    final long expiresAt;

    int delivered;
    long stored;       // delivered items waiting to be collected
    boolean closed;    // cancelled or expired

    Order(UUID id, UUID owner, String ownerName, Material material, int amount, double price,
          long createdAt, long expiresAt) {
        this.id = id;
        this.owner = owner;
        this.ownerName = ownerName;
        this.material = material;
        this.amount = amount;
        this.price = price;
        this.createdAt = createdAt;
        this.expiresAt = expiresAt;
    }

    boolean open() {
        return !closed && delivered < amount;
    }

    int remaining() {
        return amount - delivered;
    }

    double paid() {
        return Text.round2(delivered * price);
    }

    double total() {
        return Text.round2(amount * price);
    }

    int stackSize() {
        return Math.max(1, Math.min(64, material.getMaxStackSize()));
    }
}
