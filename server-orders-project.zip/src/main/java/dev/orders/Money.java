package dev.orders;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.lang.reflect.Method;
import java.util.Locale;

/** Talks to Vault's economy without needing the Vault jar at build time. */
final class Money {
    private Object provider;
    private Method has;
    private Method withdraw;
    private Method deposit;
    private Method success;

    boolean ready() {
        if (provider != null) {
            return true;
        }
        try {
            Class<?> economy = Class.forName("net.milkbowl.vault.economy.Economy");
            RegisteredServiceProvider<?> registration = Bukkit.getServicesManager().getRegistration(economy);
            if (registration == null) {
                return false;
            }
            Object found = registration.getProvider();
            Method hasMethod = economy.getMethod("has", OfflinePlayer.class, double.class);
            Method withdrawMethod = economy.getMethod("withdrawPlayer", OfflinePlayer.class, double.class);
            Method depositMethod = economy.getMethod("depositPlayer", OfflinePlayer.class, double.class);
            Class<?> response = Class.forName("net.milkbowl.vault.economy.EconomyResponse");
            Method successMethod = response.getMethod("transactionSuccess");

            provider = found;
            has = hasMethod;
            withdraw = withdrawMethod;
            deposit = depositMethod;
            success = successMethod;
            return true;
        } catch (ReflectiveOperationException | LinkageError e) {
            return false;
        }
    }

    boolean has(OfflinePlayer player, double amount) {
        try {
            return Boolean.TRUE.equals(has.invoke(provider, player, amount));
        } catch (ReflectiveOperationException e) {
            return false;
        }
    }

    boolean withdraw(OfflinePlayer player, double amount) {
        try {
            Object response = withdraw.invoke(provider, player, amount);
            return Boolean.TRUE.equals(success.invoke(response));
        } catch (ReflectiveOperationException e) {
            return false;
        }
    }

    void deposit(OfflinePlayer player, double amount) {
        try {
            deposit.invoke(provider, player, amount);
        } catch (ReflectiveOperationException e) {
            // nothing more we can do
        }
    }

    static String format(double amount) {
        if (amount == Math.rint(amount)) {
            return String.format(Locale.US, "$%,.0f", amount);
        }
        return String.format(Locale.US, "$%,.2f", amount);
    }
}
