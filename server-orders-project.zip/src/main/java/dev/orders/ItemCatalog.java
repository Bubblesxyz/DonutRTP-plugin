package dev.orders;

import org.bukkit.Material;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Every item in the game that can be ordered, sorted by name. */
final class ItemCatalog {
    private static final Set<String> BLOCKED = Set.of(
            "BARRIER", "BEDROCK", "COMMAND_BLOCK", "CHAIN_COMMAND_BLOCK", "REPEATING_COMMAND_BLOCK",
            "COMMAND_BLOCK_MINECART", "STRUCTURE_BLOCK", "STRUCTURE_VOID", "JIGSAW", "DEBUG_STICK",
            "KNOWLEDGE_BOOK", "LIGHT", "SPAWNER", "TRIAL_SPAWNER", "VAULT", "REINFORCED_DEEPSLATE",
            "END_PORTAL_FRAME", "PETRIFIED_OAK_SLAB");

    private final List<Material> items = new ArrayList<>();

    ItemCatalog() {
        for (Material material : Material.values()) {
            if (material.isLegacy() || !material.isItem() || material.isAir() || BLOCKED.contains(material.name())) {
                continue;
            }
            items.add(material);
        }
        items.sort(Comparator.comparing(Text::name));
    }

    List<Material> search(String query) {
        if (query == null || query.isBlank()) {
            return items;
        }
        String needle = query.trim().toLowerCase(Locale.ROOT);
        List<Material> result = new ArrayList<>();
        for (Material material : items) {
            if (Text.name(material).toLowerCase(Locale.ROOT).contains(needle)) {
                result.add(material);
            }
        }
        return result;
    }
}
