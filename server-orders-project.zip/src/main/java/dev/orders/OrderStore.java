package dev.orders;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/** All orders, saved in plugins/ServerOrders/orders.yml. */
final class OrderStore {
    private final Map<UUID, Order> orders = new LinkedHashMap<>();
    private final File file;

    OrderStore(File file) {
        this.file = file;
    }

    Collection<Order> all() {
        return orders.values();
    }

    void add(Order order) {
        orders.put(order.id, order);
    }

    void remove(Order order) {
        orders.remove(order.id);
    }

    Order get(UUID id) {
        return orders.get(id);
    }

    List<Order> ownedBy(UUID owner) {
        List<Order> list = new ArrayList<>();
        for (Order order : orders.values()) {
            if (order.owner.equals(owner)) {
                list.add(order);
            }
        }
        return list;
    }

    void load() {
        orders.clear();
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = yaml.getConfigurationSection("orders");
        if (root == null) {
            return;
        }
        for (String key : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(key);
            if (s == null) {
                continue;
            }
            try {
                Material material = Material.matchMaterial(s.getString("material", ""));
                if (material == null) {
                    continue;
                }
                Order order = new Order(UUID.fromString(key), UUID.fromString(s.getString("owner", "")),
                        s.getString("owner-name", "?"), material, s.getInt("amount"), s.getDouble("price"),
                        s.getLong("created"), s.getLong("expires"));
                order.delivered = s.getInt("delivered");
                order.stored = s.getLong("stored");
                order.closed = s.getBoolean("closed");
                orders.put(order.id, order);
            } catch (IllegalArgumentException e) {
                Bukkit.getLogger().warning("[ServerOrders] Skipped a broken order: " + key);
            }
        }
    }

    void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (Order o : orders.values()) {
            String p = "orders." + o.id + ".";
            yaml.set(p + "owner", o.owner.toString());
            yaml.set(p + "owner-name", o.ownerName);
            yaml.set(p + "material", o.material.name());
            yaml.set(p + "amount", o.amount);
            yaml.set(p + "price", o.price);
            yaml.set(p + "created", o.createdAt);
            yaml.set(p + "expires", o.expiresAt);
            yaml.set(p + "delivered", o.delivered);
            yaml.set(p + "stored", o.stored);
            yaml.set(p + "closed", o.closed);
        }
        try {
            yaml.save(file);
        } catch (IOException e) {
            Bukkit.getLogger().log(Level.SEVERE, "[ServerOrders] Could not save orders.yml", e);
        }
    }
}
