package dev.orders;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickCallback;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** The dialog screens (gray buttons): pick an item, create the order, search. */
final class OrdersDialogs {
    private static final int PER_PAGE = 24;

    private final OrdersPlugin plugin;

    OrdersDialogs(OrdersPlugin plugin) {
        this.plugin = plugin;
    }

    private DialogAction click(Consumer<Player> run) {
        return DialogAction.customClick((view, audience) -> {
            if (audience instanceof Player player) {
                Bukkit.getScheduler().runTask(plugin, () -> run.accept(player));
            }
        }, ClickCallback.Options.builder().uses(ClickCallback.UNLIMITED_USES).build());
    }

    // ------------------------------------------------------ pick any item

    void openSelect(Player player, String query, int page) {
        List<Material> matches = plugin.catalog().search(query);
        int pages = Math.max(1, (matches.size() + PER_PAGE - 1) / PER_PAGE);
        int current = Math.max(0, Math.min(page, pages - 1));

        List<ActionButton> buttons = new ArrayList<>();
        int end = Math.min(matches.size(), (current + 1) * PER_PAGE);
        for (int i = current * PER_PAGE; i < end; i++) {
            Material material = matches.get(i);
            buttons.add(ActionButton.builder(Component.text(Text.name(material)))
                    .width(200)
                    .action(click(p -> openCreate(p, material, "1", "1")))
                    .build());
        }

        DialogAction search = DialogAction.customClick((view, audience) -> {
            if (audience instanceof Player p) {
                String text = view.getText("query");
                String typed = text == null ? "" : text.trim();
                Bukkit.getScheduler().runTask(plugin, () -> openSelect(p, typed, 0));
            }
        }, ClickCallback.Options.builder().uses(ClickCallback.UNLIMITED_USES).build());

        buttons.add(ActionButton.builder(Component.text("Search", NamedTextColor.GREEN))
                .width(200).action(search).build());
        if (current > 0) {
            buttons.add(ActionButton.builder(Component.text("Previous page"))
                    .width(200).action(click(p -> openSelect(p, query, current - 1))).build());
        }
        if (current < pages - 1) {
            buttons.add(ActionButton.builder(Component.text("Next page"))
                    .width(200).action(click(p -> openSelect(p, query, current + 1))).build());
        }

        ActionButton back = ActionButton.builder(Component.text("Back"))
                .width(200).action(click(plugin.menu()::openYours)).build();

        DialogInput input = DialogInput.text("query", Component.text("Search any item"))
                .initial(query == null ? "" : query)
                .build();

        Component info = Component.text(matches.size() + " items - page " + (current + 1) + "/" + pages);

        Dialog dialog = Dialog.create(factory -> factory.empty()
                .base(DialogBase.builder(Component.text("ORDERS -> Select Item"))
                        .canCloseWithEscape(true)
                        .inputs(List.of(input))
                        .body(List.of(DialogBody.plainMessage(info)))
                        .build())
                .type(DialogType.multiAction(buttons, back, 2)));
        player.showDialog(dialog);
    }

    // ------------------------------------------------- create the new order

    void openCreate(Player player, Material material, String amountText, String priceText) {
        DialogInput amount = DialogInput.text("amount", Component.text("Amount"))
                .initial(amountText).build();
        DialogInput price = DialogInput.text("price", Component.text("Money Per Item"))
                .initial(priceText).build();

        DialogAction confirmAction = DialogAction.customClick((view, audience) -> {
            if (audience instanceof Player p) {
                String amountTyped = view.getText("amount");
                String priceTyped = view.getText("price");
                Bukkit.getScheduler().runTask(plugin, () -> confirm(p, material, amountTyped, priceTyped));
            }
        }, ClickCallback.Options.builder().uses(ClickCallback.UNLIMITED_USES).build());

        ActionButton confirm = ActionButton.builder(Component.text("Confirm", NamedTextColor.GREEN))
                .tooltip(Component.text("Cost = amount x money per item. Click to confirm"))
                .width(150)
                .action(confirmAction)
                .build();
        ActionButton change = ActionButton.builder(Component.text("Change Item..."))
                .width(150)
                .action(click(p -> openSelect(p, "", 0)))
                .build();

        Component info = Component.text("You're creating an order for: " + Text.name(material));

        Dialog dialog = Dialog.create(factory -> factory.empty()
                .base(DialogBase.builder(Component.text("Create A New Order"))
                        .canCloseWithEscape(true)
                        .inputs(List.of(amount, price))
                        .body(List.of(DialogBody.plainMessage(info)))
                        .build())
                .type(DialogType.confirmation(confirm, change)));
        player.showDialog(dialog);
    }

    private void confirm(Player player, Material material, String amountText, String priceText) {
        double amount = Text.parseNumber(amountText);
        double price = Text.parseNumber(priceText);
        if (Double.isNaN(amount) || amount < 1 || amount != Math.rint(amount)) {
            player.sendMessage(Text.red("Amount must be a whole number, like 64."));
            openCreate(player, material, amountText, priceText);
            return;
        }
        if (Double.isNaN(price) || price <= 0) {
            player.sendMessage(Text.red("Money Per Item must be a number, like 25 or 1.5k."));
            openCreate(player, material, amountText, priceText);
            return;
        }
        if (!plugin.createOrder(player, material, (int) amount, price)) {
            openCreate(player, material, amountText, priceText);
        }
    }

    // ------------------------------------------- search inside the order list

    void openListSearch(Player player) {
        DialogInput input = DialogInput.text("query", Component.text("Search orders by item"))
                .initial(plugin.menu().query(player))
                .build();

        DialogAction searchAction = DialogAction.customClick((view, audience) -> {
            if (audience instanceof Player p) {
                String text = view.getText("query");
                Bukkit.getScheduler().runTask(plugin, () -> {
                    plugin.menu().setQuery(p, text);
                    plugin.menu().openList(p);
                });
            }
        }, ClickCallback.Options.builder().uses(ClickCallback.UNLIMITED_USES).build());

        ActionButton search = ActionButton.builder(Component.text("Search", NamedTextColor.GREEN))
                .width(150).action(searchAction).build();
        ActionButton clear = ActionButton.builder(Component.text("Clear"))
                .width(150)
                .action(click(p -> {
                    plugin.menu().setQuery(p, "");
                    plugin.menu().openList(p);
                }))
                .build();

        Dialog dialog = Dialog.create(factory -> factory.empty()
                .base(DialogBase.builder(Component.text("ORDERS -> Search"))
                        .canCloseWithEscape(true)
                        .inputs(List.of(input))
                        .build())
                .type(DialogType.confirmation(search, clear)));
        player.showDialog(dialog);
    }
}
