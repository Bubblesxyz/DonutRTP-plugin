package dev.orders;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;

import java.util.Locale;

final class Text {
    private Text() {
    }

    static String name(Material material) {
        StringBuilder builder = new StringBuilder();
        for (String part : material.name().toLowerCase(Locale.ROOT).split("_")) {
            if (part.isEmpty()) {
                continue;
            }
            if (builder.length() > 0) {
                builder.append(' ');
            }
            builder.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return builder.toString();
    }

    static String duration(long millis) {
        long minutes = Math.max(0, millis) / 60000;
        return (minutes / 1440) + "d " + ((minutes % 1440) / 60) + "h " + (minutes % 60) + "m";
    }

    static double round2(double value) {
        return Math.round(value * 100.0) / 100.0;
    }

    static double parseNumber(String text) {
        if (text == null) {
            return Double.NaN;
        }
        String t = text.trim().toLowerCase(Locale.ROOT).replace(",", "").replace("$", "");
        if (t.isEmpty()) {
            return Double.NaN;
        }
        double multiplier = 1;
        char last = t.charAt(t.length() - 1);
        if (last == 'k') {
            multiplier = 1_000;
        } else if (last == 'm') {
            multiplier = 1_000_000;
        } else if (last == 'b') {
            multiplier = 1_000_000_000;
        }
        if (multiplier != 1) {
            t = t.substring(0, t.length() - 1);
        }
        try {
            return Double.parseDouble(t) * multiplier;
        } catch (NumberFormatException e) {
            return Double.NaN;
        }
    }

    static Component plain(Component component) {
        return component.decoration(TextDecoration.ITALIC, false);
    }

    static Component aqua(String text) {
        return Component.text(text, NamedTextColor.AQUA);
    }

    static Component white(String text) {
        return Component.text(text, NamedTextColor.WHITE);
    }

    static Component gray(String text) {
        return Component.text(text, NamedTextColor.GRAY);
    }

    static Component green(String text) {
        return Component.text(text, NamedTextColor.GREEN);
    }

    static Component red(String text) {
        return Component.text(text, NamedTextColor.RED);
    }
}
