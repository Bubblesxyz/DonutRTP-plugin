package dev.orders;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class OrdersPlugin extends JavaPlugin implements Listener, CommandExecutor {
    private final Money money = new Money();
    private OrderStore store;
    private ItemCatalog catalog;
    private OrdersMenu menu;
    private OrdersDialogs dialogs;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        store = new OrderStore(new File(getDataFolder(), "orders.yml"));
        store.load();
        catalog = new ItemCatalog();
        menu = new OrdersMenu(this);
        dialogs = new OrdersDialogs(this);

        getServer().getPluginManager().registerEvents(this, this);
        for (String name : new String[]{"orders"}) {
            PluginCommand command = getCommand(name);
            if (command != null) {
                command.setExecutor(this);
            }
        }
        // check delivery / expiry every 30 seconds
        getServer().getScheduler().runTaskTimer(this, this::tick, 600L, 600L);
    }

    @Override
    public void onDisable() {
        if (store != null) {
            store.save();
        }
    }

    Money money() {
        return money;
    }

    OrderStore store() {
        return store;
    }

    ItemCatalog catalog() {
        return catalog;
    }

    OrdersMenu menu() {
        return menu;
    }

    OrdersDialogs dialogs() {
        return dialogs;
    }

    // --------------------------------------------- items that are never auto-filled

    /**
     * False if this order must not be auto-filled: the item is on the no-auto-fill list, or the order's
     * price per item is below the item's sell price. Real players can still fill it.
     */
    boolean autoFills(Material material, double pricePerItem) {
        String name = material.name();
        for (String pattern : getConfig().getStringList("no-auto-fill")) {
            if (matches(pattern.trim().toUpperCase(Locale.ROOT), name)) {
                return false;
            }
        }
        double sellPrice = sellPrice(material);
        if (sellPrice < 0) {
            return getConfig().getBoolean("unknown-sell-price-auto-fill", true);
        }
        return pricePerItem >= sellPrice;
    }

    /** What one item sells for (same logic as SKSell). -1 = cannot be sold / unknown. */
    double sellPrice(Material material) {
        String name = material.name();
        if (getConfig().contains("sell-prices." + name)) {
            double listed = getConfig().getDouble("sell-prices." + name);
            return listed > 0 ? listed : -1;
        }
        if (!getConfig().getBoolean("auto-sell-pricing.enabled", true)) {
            return -1;
        }
        String words = name.toLowerCase(Locale.ROOT).replace('_', ' ');
        for (String never : getConfig().getStringList("auto-sell-pricing.never-sell")) {
            if (words.contains(never.toLowerCase(Locale.ROOT))) {
                return -1;
            }
        }
        for (Map<?, ?> rule : getConfig().getMapList("auto-sell-pricing.rules")) {
            Object contains = rule.get("contains");
            Object price = rule.get("price");
            if (contains instanceof List<?> list && price instanceof Number number) {
                for (Object word : list) {
                    if (words.contains(String.valueOf(word).toLowerCase(Locale.ROOT))) {
                        return number.doubleValue();
                    }
                }
            }
        }
        return getConfig().getDouble("auto-sell-pricing.default-price", 1);
    }

    private static boolean matches(String pattern, String name) {
        if (pattern.isEmpty()) {
            return false;
        }
        boolean start = pattern.startsWith("*");
        boolean end = pattern.endsWith("*");
        String core = pattern.replace("*", "");
        if (core.isEmpty()) {
            return true;
        }
        if (start && end) {
            return name.contains(core);
        }
        if (start) {
            return name.endsWith(core);
        }
        if (end) {
            return name.startsWith(core);
        }
        return name.equals(core);
    }

    // ---------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use orders.");
            return true;
        }
        menu.openList(player);
        return true;
    }

    // ----------------------------------------------------------- creating orders

    /** Returns true if the order was created. */
    boolean createOrder(Player player, Material material, int amount, double price) {
        int maxAmount = getConfig().getInt("max-amount", 2304);
        int maxOrders = getConfig().getInt("max-orders-per-player", 10);
        double minPrice = getConfig().getDouble("min-price-overrides." + material.name(),
                getConfig().getDouble("min-price", 1.0));

        if (amount > maxAmount) {
            player.sendMessage(Text.red("The most you can order at once is " + maxAmount + "."));
            return false;
        }
        if (price < minPrice) {
            player.sendMessage(Text.red("The lowest price for " + Text.name(material) + " is "
                    + Money.format(minPrice) + " each."));
            return false;
        }
        if (store.ownedBy(player.getUniqueId()).size() >= maxOrders) {
            player.sendMessage(Text.red("You can only have " + maxOrders + " orders at a time."));
            return false;
        }
        if (!money.ready()) {
            player.sendMessage(Text.red("The economy isn't available right now. Tell an admin (needs Vault + an economy plugin)."));
            return false;
        }

        double cost = Text.round2(amount * price);
        if (!money.has(player, cost)) {
            player.sendMessage(Text.red("This order costs " + Money.format(cost) + " and you don't have enough."));
            return false;
        }
        if (!money.withdraw(player, cost)) {
            player.sendMessage(Text.red("The payment failed."));
            return false;
        }

        long now = System.currentTimeMillis();
        long expires = now + (long) (getConfig().getDouble("expire-days", 7) * 86_400_000L);
        Order order = new Order(java.util.UUID.randomUUID(), player.getUniqueId(), player.getName(),
                material, amount, price, now, expires);
        store.add(order);
        store.save();

        player.sendMessage(Component.text("ORDER", NamedTextColor.RED)
                .append(Component.text(" \u00B7 ", NamedTextColor.GRAY))
                .append(Component.text("You ordered " + amount + " " + Text.name(material)
                        + " for " + Money.format(cost) + ".", NamedTextColor.WHITE)));
        if (getConfig().getBoolean("broadcast", true)) {
            Bukkit.broadcast(Component.text("ORDER", NamedTextColor.RED)
                    .append(Component.text(" \u00B7 ", NamedTextColor.GRAY))
                    .append(Component.text(player.getName(), NamedTextColor.AQUA))
                    .append(Component.text(" has ordered x" + amount + " " + Text.name(material) + " for ", NamedTextColor.WHITE))
                    .append(Component.text(Money.format(price), NamedTextColor.GREEN))
                    .append(Component.text(" each, use /orders to view it.", NamedTextColor.WHITE)));
        }
        if (!autoFills(material, price)) {
            player.sendMessage(Text.gray("This order won't be delivered automatically (item not allowed, or the price is below the sell price) - other players have to fill it."));
        }
        menu.openYours(player);
        return true;
    }

    // ------------------------------------------------- hourly delivery + expiry

    private void tick() {
        long now = System.currentTimeMillis();
        long halfAfter = (long) (getConfig().getDouble("fill.half-after-hours", 1) * 3_600_000L);
        long fullAfter = (long) (getConfig().getDouble("fill.full-after-hours", 2) * 3_600_000L);
        boolean changed = false;

        for (Order order : new ArrayList<>(store.all())) {
            if (order.open() && autoFills(order.material, order.price)) {
                long elapsed = now - order.createdAt;
                int target = elapsed >= fullAfter ? order.amount : (elapsed >= halfAfter ? order.amount / 2 : 0);
                if (target > order.delivered) {
                    int added = target - order.delivered;
                    order.delivered += added;
                    order.stored += added;
                    changed = true;
                    Player owner = Bukkit.getPlayer(order.owner);
                    if (owner != null) {
                        String state = order.delivered >= order.amount ? "fully delivered" : "half delivered";
                        owner.sendMessage(Component.text("ORDER", NamedTextColor.RED)
                                .append(Component.text(" \u00B7 ", NamedTextColor.GRAY))
                                .append(Component.text("Your order for " + Text.name(order.material) + " is " + state
                                        + " (" + order.delivered + "/" + order.amount + "). Use /orders to collect it.",
                                        NamedTextColor.WHITE)));
                    }
                }
            }

            if (order.open() && now >= order.expiresAt && money.ready()) {
                order.closed = true;
                double refund = Text.round2(order.remaining() * order.price);
                if (refund > 0) {
                    money.deposit(Bukkit.getOfflinePlayer(order.owner), refund);
                }
                changed = true;
                Player owner = Bukkit.getPlayer(order.owner);
                if (owner != null) {
                    owner.sendMessage(Text.gray("Your order for " + Text.name(order.material) + " expired. You got "
                            + Money.format(refund) + " back."));
                }
            }

            if ((order.closed || order.delivered >= order.amount) && order.stored <= 0) {
                store.remove(order);
                changed = true;
            }
        }
        if (changed) {
            store.save();
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        long waiting = 0;
        for (Order order : store.ownedBy(player.getUniqueId())) {
            waiting += order.stored;
        }
        if (waiting > 0) {
            long total = waiting;
            Bukkit.getScheduler().runTaskLater(this, () -> player.sendMessage(Component.text("ORDER", NamedTextColor.RED)
                    .append(Component.text(" \u00B7 ", NamedTextColor.GRAY))
                    .append(Component.text("You have " + total + " ordered items waiting. Use /orders to collect them.",
                            NamedTextColor.WHITE))), 60L);
        }
    }

    // ------------------------------------------------------- keep menus read-only

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof OrdersHolder holder)) {
            return;
        }
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player) || event.getClickedInventory() != top) {
            return;
        }
        int slot = event.getSlot();
        getServer().getScheduler().runTask(this, () -> menu.handleClick(player, holder, slot));
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof OrdersHolder) {
            event.setCancelled(true);
        }
    }
}
