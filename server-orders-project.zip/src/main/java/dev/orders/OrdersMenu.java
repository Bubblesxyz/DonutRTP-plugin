package dev.orders;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** The chest screens: all orders, your orders, edit order, collect items. */
final class OrdersMenu {
    private static final int PAGE = 45;
    private static final String[] SORTS = {"Most Money Per Item", "Recently Listed", "Most Delivered", "Most Paid"};

    private static final class ListState {
        int sort;
        int page;
        String query = "";
    }

    private final OrdersPlugin plugin;
    private final Map<java.util.UUID, ListState> states = new HashMap<>();

    OrdersMenu(OrdersPlugin plugin) {
        this.plugin = plugin;
    }

    private ListState state(Player player) {
        return states.computeIfAbsent(player.getUniqueId(), key -> new ListState());
    }

    String query(Player player) {
        return state(player).query;
    }

    void setQuery(Player player, String query) {
        ListState state = state(player);
        state.query = query == null ? "" : query.trim();
        state.page = 0;
    }

    // ------------------------------------------------------------- all orders

    private List<Order> visible(ListState state) {
        String needle = state.query.toLowerCase(Locale.ROOT);
        List<Order> list = new ArrayList<>();
        for (Order order : plugin.store().all()) {
            if (order.open() && (needle.isEmpty() || Text.name(order.material).toLowerCase(Locale.ROOT).contains(needle))) {
                list.add(order);
            }
        }
        Comparator<Order> comparator;
        if (state.sort == 1) {
            comparator = Comparator.comparingLong((Order o) -> o.createdAt).reversed();
        } else if (state.sort == 2) {
            comparator = Comparator.comparingInt((Order o) -> o.delivered).reversed();
        } else if (state.sort == 3) {
            comparator = Comparator.comparingDouble((Order o) -> o.paid()).reversed();
        } else {
            comparator = Comparator.comparingDouble((Order o) -> o.price).reversed();
        }
        list.sort(comparator);
        return list;
    }

    void openList(Player player) {
        ListState state = state(player);
        List<Order> list = visible(state);
        int pages = Math.max(1, (list.size() + PAGE - 1) / PAGE);
        state.page = Math.max(0, Math.min(state.page, pages - 1));

        OrdersHolder holder = new OrdersHolder(OrdersHolder.Type.LIST, null, state.page);
        Inventory inventory = Bukkit.createInventory(holder, 54, Component.text("ORDERS"));
        holder.setInventory(inventory);

        for (int i = 0; i < PAGE; i++) {
            int index = state.page * PAGE + i;
            if (index >= list.size()) {
                break;
            }
            inventory.setItem(i, orderIcon(list.get(index)));
        }

        List<Component> sortLore = new ArrayList<>();
        sortLore.add(Component.empty());
        for (int i = 0; i < SORTS.length; i++) {
            sortLore.add(Text.plain(Component.text("\u25AA " + SORTS[i], i == state.sort ? NamedTextColor.AQUA : NamedTextColor.GRAY)));
        }
        inventory.setItem(45, icon(Material.HOPPER, Text.aqua("Sort"), sortLore));
        inventory.setItem(46, icon(Material.OAK_SIGN, Text.aqua("Search"),
                List.of(Text.white(state.query.isEmpty() ? "Click to search" : "Searching: " + state.query))));
        if (state.page > 0) {
            inventory.setItem(48, icon(Material.ARROW, Text.aqua("PREVIOUS"), List.of(Text.white("Click to go to the previous page"))));
        }
        inventory.setItem(49, icon(Material.PAPER, Text.aqua("Refresh"), List.of(Text.white("Click to refresh"))));
        if (state.page < pages - 1) {
            inventory.setItem(50, icon(Material.ARROW, Text.aqua("NEXT"), List.of(Text.white("Click to go to the next page"))));
        }
        inventory.setItem(53, icon(Material.CHEST, Text.aqua("Your Orders"), List.of(Text.white("Click to view your orders"))));
        player.openInventory(inventory);
    }

    private void clickList(Player player, int slot) {
        ListState state = state(player);
        if (slot < PAGE) {
            List<Order> list = visible(state);
            int index = state.page * PAGE + slot;
            if (index < list.size()) {
                Order order = list.get(index);
                if (order.owner.equals(player.getUniqueId())) {
                    openEdit(player, order);
                } else {
                    fill(player, order);
                }
            }
        } else if (slot == 45) {
            state.sort = (state.sort + 1) % SORTS.length;
            state.page = 0;
            openList(player);
        } else if (slot == 46) {
            plugin.dialogs().openListSearch(player);
        } else if (slot == 48) {
            state.page--;
            openList(player);
        } else if (slot == 49) {
            openList(player);
        } else if (slot == 50) {
            state.page++;
            openList(player);
        } else if (slot == 53) {
            openYours(player);
        }
    }

    /** Someone else's order: hand over matching items from your inventory and get paid per item. */
    private void fill(Player player, Order order) {
        if (!order.open()) {
            player.sendMessage(Text.red("That order is already complete."));
            openList(player);
            return;
        }
        if (!plugin.money().ready()) {
            player.sendMessage(Text.red("The economy isn't available right now."));
            return;
        }

        int need = order.remaining();
        ItemStack plain = new ItemStack(order.material);
        ItemStack[] contents = player.getInventory().getStorageContents();
        int taken = 0;
        for (int i = 0; i < contents.length && taken < need; i++) {
            ItemStack stack = contents[i];
            if (stack != null && stack.isSimilar(plain)) {
                int take = Math.min(stack.getAmount(), need - taken);
                taken += take;
                stack.setAmount(stack.getAmount() - take);
                if (stack.getAmount() <= 0) {
                    contents[i] = null;
                }
            }
        }
        if (taken == 0) {
            player.sendMessage(Text.red("You don't have any " + Text.name(order.material) + " to deliver."));
            return;
        }

        player.getInventory().setStorageContents(contents);
        order.delivered += taken;
        order.stored += taken;
        double pay = Text.round2(taken * order.price);
        plugin.money().deposit(player, pay);
        plugin.store().save();

        player.sendMessage(Text.green("You delivered " + taken + "x " + Text.name(order.material)
                + " to " + order.ownerName + " and got " + Money.format(pay) + "."));
        Player owner = Bukkit.getPlayer(order.owner);
        if (owner != null) {
            owner.sendMessage(Text.green(player.getName() + " delivered " + taken + "x " + Text.name(order.material)
                    + " to your order (" + order.delivered + "/" + order.amount + "). Use /orders to collect."));
        }
        openList(player);
    }

    // ------------------------------------------------------------ your orders

    void openYours(Player player) {
        List<Order> mine = plugin.store().ownedBy(player.getUniqueId());
        OrdersHolder holder = new OrdersHolder(OrdersHolder.Type.YOURS, null, 0);
        Inventory inventory = Bukkit.createInventory(holder, 27, Component.text("Your Orders"));
        holder.setInventory(inventory);

        for (int i = 0; i < Math.min(26, mine.size()); i++) {
            inventory.setItem(i, orderIcon(mine.get(i)));
        }
        inventory.setItem(26, icon(Material.MAP, Text.aqua("New Order"), List.of(Text.white("Click to create a new order"))));
        player.openInventory(inventory);
    }

    private void clickYours(Player player, int slot) {
        List<Order> mine = plugin.store().ownedBy(player.getUniqueId());
        if (slot == 26) {
            plugin.dialogs().openSelect(player, "", 0);
        } else if (slot < mine.size() && slot < 26) {
            openEdit(player, mine.get(slot));
        }
    }

    // ------------------------------------------------------------- edit order

    void openEdit(Player player, Order order) {
        OrdersHolder holder = new OrdersHolder(OrdersHolder.Type.EDIT, order.id, 0);
        Inventory inventory = Bukkit.createInventory(holder, 27, Component.text("ORDERS -> Edit Order"));
        holder.setInventory(inventory);

        ItemStack pane = icon(Material.GRAY_STAINED_GLASS_PANE, Component.text(" "), List.of());
        for (int i = 0; i < 27; i++) {
            inventory.setItem(i, pane);
        }
        inventory.setItem(10, orderIcon(order));
        inventory.setItem(13, order.open()
                ? icon(Material.RED_TERRACOTTA, Text.aqua("CANCEL"), List.of(Text.white("Click to cancel this order")))
                : icon(Material.GRAY_STAINED_GLASS_PANE, Text.gray("CANCEL"), List.of(Text.gray("This order is no longer active"))));
        inventory.setItem(15, icon(Material.CHEST, Text.aqua("COLLECT"),
                List.of(Text.white("Click to collect items"), Text.gray(order.stored + " items waiting"))));
        inventory.setItem(18, icon(Material.ARROW, Text.aqua("BACK"), List.of(Text.white("Click to go back"))));
        player.openInventory(inventory);
    }

    private void clickEdit(Player player, OrdersHolder holder, int slot) {
        Order order = plugin.store().get(holder.orderId());
        if (order == null) {
            openYours(player);
            return;
        }
        if (slot == 13 && order.open()) {
            cancel(player, order);
        } else if (slot == 15) {
            openCollect(player, order, 0);
        } else if (slot == 18) {
            openYours(player);
        }
    }

    private void cancel(Player player, Order order) {
        if (!order.open()) {
            return;
        }
        if (!plugin.money().ready()) {
            player.sendMessage(Text.red("The economy isn't available right now - try again in a moment."));
            return;
        }
        order.closed = true;
        double refund = Text.round2(order.remaining() * order.price);
        if (refund > 0) {
            plugin.money().deposit(player, refund);
        }
        player.sendMessage(Text.green("Order cancelled. You got " + Money.format(refund) + " back."));
        plugin.store().save();
        cleanup(order);
        openYours(player);
    }

    // ------------------------------------------------------- collect the items

    /** All 45 slots are used for items, so the screen is completely filled. */
    void openCollect(Player player, Order order, int page) {
        int max = order.stackSize();
        long chunks = (order.stored + max - 1) / max;
        int pages = (int) Math.max(1, (chunks + PAGE - 1) / PAGE);
        int current = Math.max(0, Math.min(page, pages - 1));

        OrdersHolder holder = new OrdersHolder(OrdersHolder.Type.COLLECT, order.id, current);
        Inventory inventory = Bukkit.createInventory(holder, 54, Component.text("ORDERS -> Collect Items"));
        holder.setInventory(inventory);

        for (int i = 0; i < PAGE; i++) {
            long index = (long) current * PAGE + i;
            if (index >= chunks) {
                break;
            }
            int amount = (int) Math.min(max, order.stored - index * max);
            inventory.setItem(i, new ItemStack(order.material, amount));
        }

        inventory.setItem(45, icon(Material.ARROW, Text.aqua("BACK"), List.of(Text.white("Click to go back"))));
        if (current > 0) {
            inventory.setItem(46, icon(Material.ARROW, Text.aqua("PREVIOUS"), List.of(Text.white("Click to go to the previous page"))));
        }
        inventory.setItem(52, icon(Material.DISPENSER, Text.aqua("DROP ALL"), List.of(Text.white("Click to drop all items"))));
        if (current < pages - 1) {
            inventory.setItem(53, icon(Material.ARROW, Text.aqua("NEXT"), List.of(Text.white("Click to go to the next page"))));
        }
        player.openInventory(inventory);
    }

    private void clickCollect(Player player, OrdersHolder holder, int slot) {
        Order order = plugin.store().get(holder.orderId());
        if (order == null) {
            openYours(player);
            return;
        }
        int max = order.stackSize();

        if (slot < PAGE) {
            long index = (long) holder.page() * PAGE + slot;
            long chunks = (order.stored + max - 1) / max;
            if (index < chunks) {
                int amount = (int) Math.min(max, order.stored - index * max);
                Map<Integer, ItemStack> left = player.getInventory().addItem(new ItemStack(order.material, amount));
                int leftover = 0;
                for (ItemStack stack : left.values()) {
                    leftover += stack.getAmount();
                }
                if (leftover >= amount) {
                    player.sendMessage(Text.red("Your inventory is full."));
                    return;
                }
                order.stored -= (amount - leftover);
                plugin.store().save();
                if (cleanup(order)) {
                    openYours(player);
                } else {
                    openCollect(player, order, holder.page());
                }
            }
        } else if (slot == 45) {
            openEdit(player, order);
        } else if (slot == 46) {
            openCollect(player, order, holder.page() - 1);
        } else if (slot == 52) {
            long remaining = order.stored;
            while (remaining > 0) {
                int part = (int) Math.min(max, remaining);
                player.getWorld().dropItemNaturally(player.getLocation(), new ItemStack(order.material, part));
                remaining -= part;
            }
            order.stored = 0;
            plugin.store().save();
            if (cleanup(order)) {
                openYours(player);
            } else {
                openCollect(player, order, 0);
            }
        } else if (slot == 53) {
            openCollect(player, order, holder.page() + 1);
        }
    }

    /** Removes an order once it is finished and everything has been collected. */
    private boolean cleanup(Order order) {
        if ((order.closed || order.delivered >= order.amount) && order.stored <= 0) {
            plugin.store().remove(order);
            plugin.store().save();
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ clicks

    void handleClick(Player player, OrdersHolder holder, int slot) {
        switch (holder.type()) {
            case LIST -> clickList(player, slot);
            case YOURS -> clickYours(player, slot);
            case EDIT -> clickEdit(player, holder, slot);
            case COLLECT -> clickCollect(player, holder, slot);
        }
    }

    // ----------------------------------------------------------------- helpers

    private ItemStack orderIcon(Order order) {
        ItemStack stack = new ItemStack(order.material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.plain(Text.aqua(order.ownerName + "'s Order")));

        List<Component> lore = new ArrayList<>();
        lore.add(Text.plain(Text.aqua(String.valueOf(order.amount)).append(Text.white(" " + Text.name(order.material)))));
        lore.add(Text.plain(Text.aqua(Money.format(order.price)).append(Text.white(" each"))));
        lore.add(Component.empty());
        lore.add(Text.plain(Text.aqua(order.delivered + "/" + order.amount).append(Text.white(" Delivered"))));
        lore.add(Text.plain(Text.aqua(Money.format(order.paid()) + "/" + Money.format(order.total())).append(Text.white(" Paid"))));
        lore.add(Component.empty());
        if (order.open()) {
            lore.add(Text.plain(Text.gray(Text.duration(order.expiresAt - System.currentTimeMillis()) + " Until Order expires")));
        } else if (order.closed) {
            lore.add(Text.plain(Text.gray("Order closed")));
        } else {
            lore.add(Text.plain(Text.green("Completely delivered")));
        }
        if (order.open() && !plugin.autoFills(order.material, order.price)) {
            lore.add(Text.plain(Text.gray("Filled by players only")));
        }
        if (order.stored > 0) {
            lore.add(Text.plain(Text.green(order.stored + " items ready to collect")));
        }
        meta.lore(lore);
        stack.setItemMeta(meta);
        return stack;
    }

    private static ItemStack icon(Material material, Component name, List<Component> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.plain(name));
        List<Component> lines = new ArrayList<>();
        for (Component line : lore) {
            lines.add(Text.plain(line));
        }
        meta.lore(lines);
        stack.setItemMeta(meta);
        return stack;
    }
}
