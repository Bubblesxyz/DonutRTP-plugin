package dev.orders;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.UUID;

/** Marks our chest menus so clicks in them can be recognised and cancelled. */
final class OrdersHolder implements InventoryHolder {
    enum Type { LIST, YOURS, EDIT, COLLECT }

    private final Type type;
    private final UUID orderId;
    private final int page;
    private Inventory inventory;

    OrdersHolder(Type type, UUID orderId, int page) {
        this.type = type;
        this.orderId = orderId;
        this.page = page;
    }

    Type type() {
        return type;
    }

    UUID orderId() {
        return orderId;
    }

    int page() {
        return page;
    }

    void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
